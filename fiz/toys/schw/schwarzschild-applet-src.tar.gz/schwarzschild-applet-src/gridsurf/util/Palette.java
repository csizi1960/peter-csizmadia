package gridsurf.util;

import javax.media.opengl.GL;

/**
 * Palette for vertex coloring.
 * @version 08/02/2009
 * @since GridSurf 06/08/2009
 * @author Peter Csizmadia
 */
public final class Palette {
    float[] values;
    float[] rgb;

    public Palette(float[] data) {
	int n = data.length/4;
	values = new float[n];
	rgb = new float[3*n];
	for(int i = 0; i < n; ++i) {
	    values[i] = data[4*i];
	    rgb[3*i] = data[4*i + 1];
	    rgb[3*i + 1] = data[4*i + 2];
	    rgb[3*i + 2] = data[4*i + 3];
	}
    }
    public Palette(float[] arr, double min, double max, boolean logscale) {
	int n = arr.length/4;
	double min0 = arr[0];
	double max0 = arr[4*(n-1)];
	if(logscale) {
	    min0 = Math.log(min0);
	    max0 = Math.log(max0);
	    min = Math.log(min);
	    max = Math.log(max);
	}
	values = new float[n];
	rgb = new float[3*n];
	for(int i = 0; i < n; ++i) {
	    double v = arr[4*i];
	    if(logscale) {
		v = Math.log(v);
	    }
	    float f = (float)((v - min0)/(max0 - min0));
	    if(logscale) {
		values[i] = (float)Math.exp((min + f*(max - min)));
	    } else {
		values[i] = (float)(min + f*(max - min));
	    }
	    rgb[3*i + 0] = arr[4*i + 1];
	    rgb[3*i + 1] = arr[4*i + 2];
	    rgb[3*i + 2] = arr[4*i + 3];
	}
    }
    private Palette(float[] vals, float[] rgb) {
	this.values = vals;
	this.rgb = rgb;
    }
    public void vertexColor(GL gl, float v) {
	int index;
	if(v <= values[0]) {
	    gl.glColor3f(rgb[0], rgb[1], rgb[2]);
	} else if(v >= values[values.length - 1]) {
	    int k = 3*(values.length - 1);
	    gl.glColor3f(rgb[k + 0], rgb[k + 1], rgb[k + 2]);
	} else {
	    for(int i = 1; i < values.length; ++i) {
		if(v >= values[i-1] && v < values[i]) {
		    float w = (values[i] - v)/(values[i] - values[i-1]);
		    float r = w*rgb[3*(i-1) + 0] + (1-w)*rgb[3*i + 0];
		    float g = w*rgb[3*(i-1) + 1] + (1-w)*rgb[3*i + 1];
		    float b = w*rgb[3*(i-1) + 2] + (1-w)*rgb[3*i + 2];
		    gl.glColor3f(r, g, b);
		    return;
		}
	    }
	    gl.glColor3f(1.0f, 1.0f, 1.0f);
	}
    }
    public Palette lighter(float f) {
	float[] newvalues = new float[values.length];
	float[] newrgb = new float[rgb.length];
	for(int i = 0; i < values.length; ++i) {
	    newvalues[i] = values[i];
	    float r = rgb[3*i + 0];
	    float g = rgb[3*i + 1];
	    float b = rgb[3*i + 2];
	    newrgb[3*i + 0] = r + (1-r)*f;
	    newrgb[3*i + 1] = g + (1-g)*f;
	    newrgb[3*i + 2] = b + (1-b)*f;
	}
	return new Palette(newvalues, newrgb);
    }
    public Palette normalize(double min, double max, boolean logscale) {
	if(logscale) {
	    min = Math.log(min);
	    max = Math.log(max);
	}
	int n = values.length;
	float[] newvalues = new float[n];
	for(int i = 0; i < n; ++i) {
	    float x = values[i];
	    if(logscale) {
		newvalues[i] = (float)Math.exp((Math.log(x) - min)/(max - min));
	    } else {
		newvalues[i] = (float)((x - min)/(max - min));
	    }
	}
	float[] newrgb = new float[3*n];
	System.arraycopy(rgb, 0, newrgb, 0, 3*n);
	return new Palette(newvalues, newrgb);
    }
    public boolean equals(Palette o) {
	if(values.length != o.values.length) {
	    return false;
	}
	for(int i = 0; i < values.length; ++i) {
	    if(values[i] != o.values[i]) {
		return false;
	    }
	}
	for(int i = 0; i < rgb.length; ++i) {
	    if(rgb[i] != o.rgb[i]) {
		return false;
	    }
	}
	return true;
    }
}
