package schwarzschild_demo;

/**
 * Geodesic worldline of a free particle in Schwarzschild geometry.
 * @since 03/13/2008
 * @author Peter Csizmadia
 */
public class Geodesic {
    private static final int NUM_COMPS = 5;
    private static final int I_t = 0;
    private static final int I_r = 1;
    private static final int I_phi = 2;
    private static final int I_vr = 3;
    private static final int I_vphi = 4;
    private double r_s;
    private double[] rk4k1;
    private double[] rk4k2;
    private double[] rk4k3;
    private double[] rk4k4;
    private double[] coords;
    private double[] coords2;
    private double[] coords3;
    private double[] coords4;
    private double[] prevCoords;
    private double prevPhysicalTime;
    private double precision;
    private double interpolationWeight;
    private double approxPeriod;
    private float[] worldLine;
    private int worldLinePos;
    private float worldLineStartT;
    private double worldLineFutureT;
    private int worldLineEnd;
    private boolean worldLineMemorized;

    public Geodesic(double r_s, double r, double phi, double vr, double vphi,
		    double t_future) {
	rk4k1 = new double[NUM_COMPS];
	rk4k2 = new double[NUM_COMPS];
	rk4k3 = new double[NUM_COMPS];
	rk4k4 = new double[NUM_COMPS];
	coords = new double[NUM_COMPS];
	coords2 = new double[NUM_COMPS];
	coords3 = new double[NUM_COMPS];
	coords4 = new double[NUM_COMPS];
	prevCoords = new double[NUM_COMPS];
	prevPhysicalTime = 0;
	coords[I_t] = 0;
	coords[I_r] = r;
	coords[I_phi] = phi*Math.PI/180;
	coords[I_vr] = vr;
	coords[I_vphi] = vphi*Math.PI/180;
	this.r_s = r_s;
	precision = 1;
	approxPeriod = Math.sqrt(8*Math.PI*Math.PI*r*r*r/r_s);
	worldLineFutureT = t_future;
	worldLine = new float[6];
	worldLine[0] = 0;
	worldLine[1] = (float)(r*Math.cos(phi*Math.PI/180));
	worldLine[2] = (float)(r*Math.sin(phi*Math.PI/180));
	worldLinePos = 1;
	worldLineEnd = 1;
	worldLineMemorized = false;
	precalc();
    }

    public void setPrecision(double p) {
	precision = p;
    }

    public float getTf() {
	double q = interpolationWeight;
	double t1 = worldLine[3*(worldLinePos - 1)];
	double t2 = worldLine[3*worldLinePos];
	return (float)((1-q)*t1 + q*t2);
    }

    public float[] getXYf() {
	double q = interpolationWeight;
	double x1 = worldLine[3*(worldLinePos - 1) + 1];
	double y1 = worldLine[3*(worldLinePos - 1) + 2];
	double x2 = worldLine[3*worldLinePos + 1];
	double y2 = worldLine[3*worldLinePos + 2];
	return new float[] {(float)((1-q)*x1 + q*x2), (float)((1-q)*y1 + q*y2)};
    }

    public boolean isWorldLineMemorized() {
	return worldLineMemorized;
    }

    public void setWorldLineMemorized(boolean v) {
	worldLineMemorized = v;
	if(v) {
	    resetWorldLineStartT();
	} else {
	    worldLinePos = 1;
	}
    }

    public float getWorldLineStartT() {
	return worldLineStartT;
    }

    public void resetWorldLineStartT() {
	worldLineStartT = getTf();
    }

    public int getWorldLineStepCount() {
	return worldLineEnd;
    }

    public int getWorldLineCurrentStep() {
	return worldLinePos;
    }

    public float[] getWorldLine2f() {
	return worldLine;
    }

    public double getApproxPeriod() {
	return approxPeriod;
    }

    public void run(double tstop) {
	precalc();
	for(int i = worldLinePos; i < worldLineEnd; ++i) {
	    if(worldLine[3*i] >= tstop) {
		worldLinePos = i;
		break;
	    }
	}
	interpolationWeight = (tstop - worldLine[3*(worldLinePos - 1)])
		/(worldLine[3*worldLinePos] - worldLine[3*(worldLinePos - 1)]);
    }

    private void precalc() {
	double tstop = worldLine[3*(worldLinePos - 1)] + worldLineFutureT;
	while(worldLine[3*(worldLineEnd - 1)] < tstop) {
	    step();
	    double t = coords[I_t];
	    double r = coords[I_r];
	    double phi = coords[I_phi];
	    if(3*worldLineEnd >= worldLine.length) {
		float[] tmp = new float[3*(worldLineEnd*3/2)];
		System.arraycopy(worldLine, 0, tmp, 0, 3*worldLineEnd);
		worldLine = tmp;
	    }
	    worldLine[3*worldLineEnd] = (float)t;
	    worldLine[3*worldLineEnd + 1] = (float)(r*Math.cos(phi));
	    worldLine[3*worldLineEnd + 2] = (float)(r*Math.sin(phi));
	    ++worldLineEnd;
	}
    }

    public void step() {
	// 4th order Runge-Kutta method
	double dt = precision*calcBestDeltaT();
	double[] k1 = rk4k1;
	double[] k2 = rk4k2;
	double[] k3 = rk4k3;
	double[] k4 = rk4k4;
	calcAcceleration(coords, k1);
	for(int i = 0; i < NUM_COMPS; ++i) {
	    coords2[i] = coords[i] + k1[i]*dt/2;
	}
	calcAcceleration(coords2, k2);
	for(int i = 0; i < NUM_COMPS; ++i) {
	    coords3[i] = coords[i] + k2[i]*dt/2;
	}
	calcAcceleration(coords3, k3);
	for(int i = 0; i < NUM_COMPS; ++i) {
	    coords4[i] = coords[i] + k3[i]*dt;
	}
	calcAcceleration(coords4, k4);
	for(int i = 0; i < NUM_COMPS; ++i) {
	    coords[i] += (k1[i] + k2[i] + k3[i] + k4[i])*dt/6;
	}
	interpolationWeight = 1;
    }

    private void calcAcceleration(double[] x, double[] dx) {
	double r = x[I_r];
	double phi = x[I_phi];
	double vr = x[I_vr];
	double vphi = x[I_vphi];
	dx[I_t] = r/(r - r_s);
	dx[I_r] = vr;
	dx[I_phi] = vphi;
//	dx[I_vr] = -r_s/(2*r*r) + r*vphi*vphi; // Newton
	dx[I_vr] = -r_s/(2*r*(r-r_s))*(1-vr*vr) + (r-r_s)*vphi*vphi; // Schw.
	dx[I_vphi] = -2*vphi*vr/r;
    }

    private double calcBestDeltaT() {
	double r = coords[I_r];
	double vr = coords[I_vr];
	double vphi = coords[I_vphi];
	double v = Math.sqrt(vr*vr + r*r*vphi*vphi);
	return r_s/v;
    }
}
