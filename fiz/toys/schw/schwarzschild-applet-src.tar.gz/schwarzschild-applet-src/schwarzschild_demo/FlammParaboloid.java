package schwarzschild_demo;

import javax.media.opengl.GL;
import gridsurf.util.Palette;

/**
 * Modified Flamm's paraboloid. It is modified inside a specified radius R
 * (greater than the Schwarzschild radius) to avoid becoming a black hole.
 * @since 03/14/2008
 * @author Peter Csizmadia
 */
public class FlammParaboloid {

    private double r_s;
    private double R;
    private double Rsq;
    private float a = (float)(r_s/(8*R*Math.sqrt(r_s*(R-r_s))));
    private float wmax;
    private float xmin;
    private float ymin;
    private float xmax;
    private float ymax;

    public FlammParaboloid(double r_s, double R,
			   float xmin, float xmax, float ymin, float ymax) {
	this.r_s = r_s;
	this.R = R;
	this.Rsq = R*R;
	this.a = (float)(r_s/(4*R*Math.sqrt(r_s*(R-r_s))));
	this.xmin = xmin;
	this.xmax = xmax;
	this.ymin = ymin;
	this.ymax = ymax;
	this.wmax = (float)calcWmax(r_s, xmin, xmax, ymin, ymax);
    }

    public double getSchwarzschildRadius() {
	return r_s;
    }

    public void draw(GL gl, float dx, Palette pal) {
	gl.glShadeModel(GL.GL_SMOOTH);
	gl.glNormal3f(0.0f, 0.0f, 1.0f);
	int xresolution = (int)Math.round((xmax - xmin)/dx);
	int yresolution = (int)Math.round((ymax - ymin)/dx);
	for(int j = 0; j < yresolution; ++j) {
	    gl.glBegin(GL.GL_QUAD_STRIP);
	    float y1 = (float)(ymin + (ymax - ymin)*j/yresolution);
	    float y2 = (float)(ymin + (ymax - ymin)*(j+1)/yresolution);
	    for(int i = 0; i <= xresolution; ++i) {
		float x = (float)(xmin + (xmax - xmin)*i/xresolution);
		vertex(gl, x, y1, pal);
		vertex(gl, x, y2, pal);
	    }
	    gl.glEnd();
	}
    }

    public float zcoord(float x, float y) {
	double rsq = x*x + y*y;
	float z;
	if(rsq > Rsq) {
	    double r = Math.sqrt(rsq);
	    z = (float)(2*Math.sqrt(r_s*(r - r_s)) - wmax);
	} else {
	    z = (float)(a*(rsq - Rsq) + 2*Math.sqrt(r_s*(R-r_s)) - wmax);
	}
	return z;
    }

    private void vertex(GL gl, float x, float y, Palette pal) {
	double rsq = x*x + y*y;
	float z, nx, ny;
	if(rsq > Rsq) {
	    double r = Math.sqrt(rsq);
	    z = (float)(2.0*Math.sqrt(r_s*(r - r_s)) - wmax);
	    double c = r_s/(2*r*Math.sqrt(r_s*(r-r_s)));
	    nx = (float)(c*x);
	    ny = (float)(c*y);
	} else {
	    z = (float)(a*(rsq - Rsq) + Math.sqrt(r_s*(R-r_s)) - wmax);
	    double c = 2*a;
	    nx = 2*a*x;
	    ny = 2*a*y;
	}
	pal.vertexColor(gl, z);
	gl.glNormal3f(-nx, -ny, 1.0f);
	gl.glVertex3d(x, y, z);
    }

    private static double calcWmax(double r_s, double xmin, double xmax,
				   double ymin, double ymax) {
	double r1 = Math.sqrt(xmin*xmin + ymin*ymin);
	double r2 = Math.sqrt(xmin*xmin + ymax*ymax);
	double r3 = Math.sqrt(xmax*xmax + ymin*ymin);
	double r4 = Math.sqrt(xmax*xmax + ymax*ymax);
	double max = r1 > r2? r1 : r2;
	if(r3 > max) {
	    max = r3;
	}
	if(r4 > max) {
	    max = r4;
	}
	return 2*Math.sqrt(r_s*(max - r_s));
    }
}
