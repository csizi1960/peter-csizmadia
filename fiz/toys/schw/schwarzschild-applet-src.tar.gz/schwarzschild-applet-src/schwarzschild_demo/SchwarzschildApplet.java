package schwarzschild_demo;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import javax.media.opengl.GLCanvas;
import javax.media.opengl.GLCapabilities;
import javax.swing.JTextArea;
import javax.swing.JScrollPane;
import com.sun.opengl.util.Animator;
import com.sun.opengl.util.FPSAnimator;

/**
 * Schwarzschild simulation applet.
 * @version 08/02/2009
 * @since 03/20/2008
 * @author Peter Csizmadia
 */
public class SchwarzschildApplet extends javax.swing.JApplet {
    private Animator animator;

    public void init() {
	animator = null;
	SchwarzschildSim schw = new SchwarzschildSim();
	setLayout(new BorderLayout());
	GLCanvas canvas = new GLCanvas();
	GLCapabilities glcap = canvas.getChosenGLCapabilities();
//	if(glcap != null && glcap.getHardwareAccelerated()) {
	    canvas.addGLEventListener(schw);
	    canvas.setSize(getSize());
	    getContentPane().add(canvas, BorderLayout.CENTER);
	    animator = new FPSAnimator(canvas, 60);
/*	} else {
	    StringBuilder sb = new StringBuilder(
		"Sorry, it does not work on your system.\n"+
		"3D accelerated graphics does not seem to be available.\n");
	    if(glcap != null) {
		sb.append("\nDetails:\n");
		sb.append(glcap.toString());
	    }
	    error(sb.toString());
	}*/
    }

    private void error(String msg) {
	setLayout(new GridLayout(1, 1));
	JTextArea txtarea = new JTextArea(msg);
	txtarea.setLineWrap(true);
	getContentPane().add(new JScrollPane(txtarea));
    }

    public void start() {
	if(animator != null) {
	    animator.start();
	}
    }

    public void stop() {
	if(animator != null) {
	    animator.stop();
	}
    }
}
