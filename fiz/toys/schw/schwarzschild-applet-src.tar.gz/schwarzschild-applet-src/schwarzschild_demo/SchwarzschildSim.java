package schwarzschild_demo;

import java.awt.Dimension;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import javax.media.opengl.*;
import com.sun.opengl.util.GLUT;
import gridsurf.util.Palette;

/**
 * Simulation of geodesics in Schwarzschild geometry.
 * @since 03/14/2008
 * @author Peter Csizmadia
 */
public class SchwarzschildSim implements GLEventListener,
       MouseListener, MouseMotionListener {

    private static final float[] sun_emission = new float[] {
	    -0.25f, -0.25f, 0.0f, 1.0f};
    private static final float[] sun_worldline_emission = new float[] {
	    0.25f, 0.25f, 0.5f, 1.0f};
    private float view_rotx = 180.0f;
    private float view_roty = 0.0f;
    private float view_rotz = 0.0f;
    private float z0 = -3.0f;
    private long time1 = 3000;
    private boolean initialized;
    private long startTime;
    private long lastDisplayTime;
    private boolean worldLineStarted;
    private FlammParaboloid flamm;
    private int theCurvedSpace;
    private int theSun;
    private Geodesic[] geodesics;
    private double timeFactor;
    private int[] balls;

    private int prevMouseX, prevMouseY;
    private boolean mouseRButtonDown = false;
    private KeyListener keyListener = null;
    private Exit exit = null;

    public interface Exit {
	void exit();
    }

    public SchwarzschildSim() {
	initialized = false;
    }

    public void setKeyListener(KeyListener l) {
	keyListener = l;
    }

    public void setExit(Exit x) {
	exit = x;
    }

    public void init(GLAutoDrawable drawable) {
	// drawable.setGL(new DebugGL(drawable.getGL()));

	GL gl = drawable.getGL();
	GLUT glut = new GLUT();
	float[] lightGray = new float[] {0.75f, 0.75f, 0.75f, 1.0f};
	float[] darkGray = new float[] {0.25f, 0.25f, 0.25f, 1.0f};
	float[] blue = new float[] {0.5f, 0.5f, 1.0f, 1.0f};

	System.err.println("INIT GL IS: " + gl.getClass().getName());
	System.err.println("Chosen GLCapabilities: " + drawable.getChosenGLCapabilities());

	gl.setSwapInterval(1);

	gl.glEnable(GL.GL_LIGHTING);
	gl.glLightfv(GL.GL_LIGHT0, GL.GL_AMBIENT_AND_DIFFUSE,
		     new float[]{1.0f, 1.0f, 1.0f, 1.0f}, 0);
	gl.glLightfv(GL.GL_LIGHT0, GL.GL_POSITION,
		     new float[]{5.0f, 5.0f, 10.0f, 0.0f}, 0);
//	gl.glLightfv(GL.GL_LIGHT0, GL.GL_POSITION,
//		     new float[]{0.0f, 0.0f, 10.0f, 0.0f}, 0);
	gl.glEnable(GL.GL_LIGHT0);
	gl.glLightfv(GL.GL_LIGHT1, GL.GL_DIFFUSE,
		     new float[]{0.5f, 0.5f, 0.0f, 1.0f}, 0);
	gl.glLightfv(GL.GL_LIGHT1, GL.GL_POSITION,
		     new float[]{5.0f, 5.0f, -20.0f, 0.0f}, 0);
	gl.glEnable(GL.GL_LIGHT1);
	gl.glEnable(GL.GL_DEPTH_TEST);

	/* line antialiasing */
	gl.glEnable(GL.GL_LINE_SMOOTH);
	gl.glHint(GL.GL_LINE_SMOOTH_HINT, GL.GL_NICEST);
	gl.glEnable(GL.GL_BLEND);
	gl.glBlendFunc(GL.GL_SRC_ALPHA, GL.GL_ONE_MINUS_SRC_ALPHA);

	/* make the curved space */
	theCurvedSpace = gl.glGenLists(1);
	gl.glNewList(theCurvedSpace, GL.GL_COMPILE);
//	gl.glEnable(GL.GL_BLEND);
//	gl.glDepthMask(false);
//	gl.glBlendFunc(GL.GL_SRC_ALPHA, GL.GL_ONE);
	gl.glEnable(GL.GL_COLOR_MATERIAL);
//	gl.glMaterialfv(GL.GL_FRONT_AND_BACK, GL.GL_AMBIENT_AND_DIFFUSE,
//			new float[] {0.5f, 0.5f, 0.5f, 1.0f}, 0);
	gl.glShadeModel(GL.GL_SMOOTH);
	gl.glMaterialfv(GL.GL_FRONT_AND_BACK, GL.GL_EMISSION,
			new float[] {-0.3f, -0.3f, -0.1f, 1.0f}, 0);
	flamm = new FlammParaboloid(0.5, 1.0, -20.0f, 20.0f, -20, 20.0f);
	Palette pal = new Palette(new float[] {
	    -8f, 1.0f, 1.0f, 0.0f, // yellow
	    -6f, 1.0f, 0.0f, 0.0f, // red
	    -4f, 0.0f, 0.0f, 1.0f, // blue
	    -3f, 0.5f, 0.8f, 0.8f, // gray
	    0.1f, 0.5f, 0.5f, 0.5f // gray
	});
	flamm.draw(gl, 0.5f, pal);
//	gl.glDepthMask(true);
//	gl.glDisable(GL.GL_BLEND);
	gl.glEndList();

	theSun = gl.glGenLists(1);
	gl.glNewList(theSun, GL.GL_COMPILE);
	gl.glMaterialfv(GL.GL_FRONT, GL.GL_EMISSION, sun_emission, 0);
	glut.glutSolidSphere(0.5f, 20, 20);
//	HalfSphere.draw(gl, 0.5f, 20, 20);
	gl.glEndList();

	geodesics = new Geodesic[1];
	balls = new int[1];

	geodesics[0] = new Geodesic(flamm.getSchwarzschildRadius(),
				    10.0, 180.0, 0.0, 0.8, 700.0);
	balls[0] = gl.glGenLists(1);
	gl.glNewList(balls[0], GL.GL_COMPILE);
	gl.glShadeModel(GL.GL_SMOOTH);
	gl.glMaterialfv(GL.GL_FRONT, GL.GL_EMISSION,
			new float[] {-0.25f, -0.25f, -1.0f, 1.0f}, 0);
	glut.glutSolidSphere(0.25f, 20, 20);
//	HalfSphere.draw(gl, 0.25f, 20, 20);
	gl.glEndList();

	gl.glEnable(GL.GL_NORMALIZE);

	drawable.addMouseListener(this);
	drawable.addMouseMotionListener(this);
	if(keyListener != null) {
	    drawable.addKeyListener(keyListener);
	}
	double minperiod = Double.MAX_VALUE;
	for(int i = 0; i < geodesics.length; ++i) {
	    double T = geodesics[i].getApproxPeriod();
	    if(T < minperiod) {
		minperiod = T;
	    }
	}
	timeFactor = 0.125*minperiod;
	if(!initialized) {
	    startTime = System.currentTimeMillis();
	    worldLineStarted = false;
	    lastDisplayTime = 0;
	    initialized = true;
	}
    }

    public void reshape(GLAutoDrawable drawable,
			int x, int y, int width, int height) {
	GL gl = drawable.getGL();

	float h = (float)height / (float)width;

	gl.glMatrixMode(GL.GL_PROJECTION);

	System.err.println("GL_VENDOR: " + gl.glGetString(GL.GL_VENDOR));
	System.err.println("GL_RENDERER: " + gl.glGetString(GL.GL_RENDERER));
	System.err.println("GL_VERSION: " + gl.glGetString(GL.GL_VERSION));
	gl.glLoadIdentity();
	gl.glFrustum(-1.0f, 1.0f, -h, h, 1.0f, 100.0f);
	gl.glMatrixMode(GL.GL_MODELVIEW);
	gl.glLoadIdentity();
	gl.glTranslatef(0.0f, 0.0f, -20.0f);
    }

    public void display(GLAutoDrawable drawable) {
	long tmillis = System.currentTimeMillis() - startTime;
	double dtmillis = (double)(tmillis - lastDisplayTime)/time1;
	float angle = tmillis < time1? (float)(100*
		Math.cos(Math.PI*tmillis/time1 - Math.PI/2)*Math.PI*dtmillis/2)
		: 0.0f;
	double c = 0.03;
	lastDisplayTime = tmillis;
	view_rotx += angle;
	GL gl = drawable.getGL();
	if ((drawable instanceof GLJPanel) &&
		!((GLJPanel) drawable).isOpaque() &&
		((GLJPanel) drawable).shouldPreserveColorBufferIfTranslucent()) {
	    gl.glClear(GL.GL_DEPTH_BUFFER_BIT);
	} else {
	    gl.glClear(GL.GL_COLOR_BUFFER_BIT | GL.GL_DEPTH_BUFFER_BIT);
	}

	gl.glPushMatrix();
	gl.glRotatef(view_rotx, 1.0f, 0.0f, 0.0f);
	gl.glRotatef(view_roty, 0.0f, 1.0f, 0.0f);
	gl.glRotatef(view_rotz, 0.0f, 0.0f, 1.0f);

	float dzminus, dzplus, dzinf;
	if(worldLineStarted) {
	    Geodesic geod = geodesics[0];
	    float[] worldLine = geod.getWorldLine2f();
	    int n = geod.getWorldLineStepCount();
	    dzminus = (float)(c*(worldLine[0] - geod.getWorldLineStartT()));
	    dzplus = (float)(c*(geod.getTf() - geod.getWorldLineStartT()));
	    dzinf = (float)(c*(worldLine[3*(n-1)] - worldLine[0]));
	    if(dzplus > 23) {
		for(int i = 0; i < geodesics.length; ++i) {
		    geodesics[i].resetWorldLineStartT();
		}
	    }
	} else {
	    dzminus = dzplus = dzinf = 0;
	}
	displaySpace(gl, dzplus);
	displaySun(gl, dzminus, dzplus, dzinf);
	for(int i = 0; i < balls.length; ++i) {
	    geodesics[i].run(timeFactor*tmillis/time1);
	    displayGeodesic(gl, geodesics[i], balls[i], c);
	}
	gl.glPopMatrix();
    }

    private void displaySpace(GL gl, float dz) {
	gl.glPushMatrix();
	gl.glTranslatef(0.0f, 0.0f, z0 + dz);
	gl.glRotatef(0.0f, 0.0f, 0.0f, 1.0f);
	gl.glCallList(theCurvedSpace);
	gl.glPopMatrix();
    }

    private void displaySun(GL gl, float dzminus, float dzplus, float dzinf) {
	gl.glPushMatrix();
	gl.glTranslatef(0.0f, 0.0f, flamm.zcoord(0.0f, 0.0f) + z0 + dzplus);
	gl.glRotatef(0.0f, 0.0f, 0.0f, 1.0f);
	gl.glCallList(theSun);
	gl.glPopMatrix();
	if(worldLineStarted) {
	    gl.glMaterialfv(GL.GL_FRONT, GL.GL_EMISSION,
			    sun_worldline_emission, 0);
	    gl.glLineWidth(4.0f);
	    gl.glBegin(GL.GL_LINE);
	    gl.glVertex3f(0.0f, 0.0f, flamm.zcoord(0.0f, 0.0f) + z0 + dzminus);
	    gl.glVertex3f(0.0f, 0.0f, flamm.zcoord(0.0f, 0.0f) + z0 + dzinf);
	    gl.glEnd();
	}
    }

    private void displayGeodesic(GL gl, Geodesic geod, int ball,
				 double c) {
	float[] xy = geod.getXYf();
	gl.glPushMatrix();
	int n = geod.getWorldLineStepCount();
	if(n > 1 && geod.isWorldLineMemorized()) {
	    float dt = geod.getTf() - geod.getWorldLineStartT();
	    float dz = (float)(c*dt);
	    float[] worldLine = geod.getWorldLine2f();
	    gl.glMaterialfv(GL.GL_FRONT, GL.GL_EMISSION,
		    new float[] {0.25f, 0.25f, -0.25f, 1.0f}, 0);
	    gl.glLineWidth(4.0f);
	    gl.glBegin(GL.GL_LINE_STRIP);
	    for(int j = 0; j < n; ++j) {
		float t = worldLine[3*j];
		float x = worldLine[3*j + 1];
		float y = worldLine[3*j + 2];
		float z = flamm.zcoord(x, y) + z0;
		z += (float)(c*(t - geod.getWorldLineStartT()));
		gl.glVertex3f(x, y, z);
	    }
	    gl.glEnd();
	    gl.glTranslatef(xy[0], xy[1], flamm.zcoord(xy[0], xy[1]) + z0 + dz);
	} else {
	    gl.glTranslatef(xy[0], xy[1], flamm.zcoord(xy[0], xy[1]) + z0);
	}
	gl.glRotatef(0.0f, 0.0f, 0.0f, 1.0f);
	gl.glCallList(ball);
	gl.glPopMatrix();
    }

    public void displayChanged(GLAutoDrawable drawable,
			       boolean modeChanged, boolean deviceChanged) { }

    // Methods required for the implementation of MouseListener
    public void mouseEntered(MouseEvent ev) {}

    public void mouseExited(MouseEvent ev) {}

    public void mousePressed(MouseEvent ev) {
	prevMouseX = ev.getX();
	prevMouseY = ev.getY();
	if((ev.getModifiers() & ev.BUTTON3_MASK) != 0) {
	    mouseRButtonDown = true;
	}
    }

    public void mouseReleased(MouseEvent ev) {
	if((ev.getModifiers() & ev.BUTTON3_MASK) != 0) {
	    mouseRButtonDown = false;
	}
    }

    public void mouseClicked(MouseEvent ev) {
	if(!worldLineStarted) {
	    worldLineStarted = true;
	    for(int i = 0; i < geodesics.length; ++i) {
		geodesics[i].setWorldLineMemorized(true);
	    }
	} else if(exit != null) {
	    exit.exit();
	}
    }

    // Methods required for the implementation of MouseMotionListener
    public void mouseDragged(MouseEvent ev) {
	int x = ev.getX();
	int y = ev.getY();
	Dimension size = ev.getComponent().getSize();

	float thetaY = 360.0f * ( (float)(x-prevMouseX)/(float)size.width);
	float thetaX = 360.0f * ( (float)(prevMouseY-y)/(float)size.height);

	prevMouseX = x;
	prevMouseY = y;

	view_rotx += thetaX;
	view_roty += thetaY;
    }

    public void mouseMoved(MouseEvent ev) {}
}
