/*
 * slopefit 1.2, Copyright (C) 1996-2000 Peter Csizmadia
 *
 * This program is protected under the terms of the GNU General Public
 * License (GPL) as published by the Free Software Foundation, Inc.,
 * 675 Mass Ave, Cambridge MA 02139, USA; either version 2 of the
 * License, or (at your option) any later version.
 * http://www.gnu.org/copyleft/gpl.html
 */
#include <math.h>
#include "bessel.h"
#include "K0I0FF.h"

double K0I0FF::eval(double x, const double* A) const
{
    double gamma = 1/sqrt(1-A[2]*A[2]);
    return A[0]*x*besselK0(gamma*x/A[1])*besselI0(gamma*A[2]*sqrt(x*x-1)/A[1]);
}

void K0I0FF::getDerivatives(double x, int n, double* D, double* Q) const
{
    double gamma2 = 1/(1-A[2]*A[2]);
    double gamma = sqrt(gamma2);
    double alpha = gamma*A[2]*sqrt(x*x-1)/A[1];
    double beta = gamma*x/A[1];
    double k0 = besselK0(beta);
    double i0 = besselI0(alpha);
    double a = k0*i0;
    D[0] = a*x;
    Q[n*0+0] = 0;
    if(n > 1) {
	double T2 = A[1]*A[1];
	double k1 = besselK1(beta);
	double i1 = besselI1(alpha);
	double da1dt = k1*beta/A[1];
	double da2dt = -i1*alpha/A[1];
	double dadt = da1dt*i0 + k0*da2dt;
	D[1] = A[0]*dadt*x;
	Q[n*1+0] = Q[n*0+1] = dadt*x;
	double d2a1dt2 = (k0*beta-k1)*beta/T2;
	double d2a2dt2 = (i0*alpha+i1)*alpha/T2;
	Q[n*1+1] = A[0]*(d2a1dt2*i0+2*da1dt*da2dt+k0*d2a2dt2)*x;
	if(n > 2) {
	    double v2 = A[2]*A[2];
	    double da1dv = -k1*gamma2*A[2]*beta;
	    double da2dv = i1*gamma2/A[2]*alpha;
	    double dadv = da1dv*i0 + k0*da2dv;
	    D[2] = A[0]*dadv*x;
	    Q[n*2+0] = Q[n*0+2] = dadv*x;
	    double d2a1dvdt = -k0*gamma2*A[2]*beta*beta/A[1];
	    double d2a2dvdt = -gamma2*alpha/(A[1]*A[2])*i0*alpha;
	    Q[n*2+1] = Q[n*1+2] = A[0]*(d2a1dvdt*i0 +
			da1dv*da2dt + da1dt*da2dv + k0*d2a2dvdt)*x;
	    double d2a1dv2 = gamma2*beta*(gamma2*v2*beta*k0-k1*(1+2*gamma2*v2));
	    double d2a2dv2 = gamma2*(3*A[2]*da2dv +
			(i0*alpha-i1)*gamma2*alpha/v2);
	    Q[n*2+2] = A[0]*(d2a1dv2*i0 + 2*da1dv*da2dv + k0*d2a2dv2)*x;
	}
    }
}
