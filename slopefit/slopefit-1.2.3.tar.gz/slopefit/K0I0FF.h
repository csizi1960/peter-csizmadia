/*
 * slopefit 1.2, Copyright (C) 1996-2000 Peter Csizmadia
 *
 * This program is protected under the terms of the GNU General Public
 * License (GPL) as published by the Free Software Foundation, Inc.,
 * 675 Mass Ave, Cambridge MA 02139, USA; either version 2 of the
 * License, or (at your option) any later version.
 * http://www.gnu.org/copyleft/gpl.html
 */
#ifndef K0I0_H
#define K0I0_H

#include "FittingFunc.h"

class K0I0FF: public FittingFunc {
public:
    K0I0FF(): FittingFunc(3) { }
    const char* getName() const { return "K0I0"; }
    double eval(double x, const double* A) const;
    virtual const char* getLabel(int i) const {
	return (i==0)? "A" : (i==1)? "T" : (i==2)? "vt" : "NONE";
    }
    double getMin(int i) const { return 0.0; }
    double getMax(int i) const { return (i==0)? 1e20 : (i==1)? 100.0 : 1.0; }
    void getDerivatives(double x, int n, double* D, double* Q) const;
};

#endif /* K0I0FF_H */
