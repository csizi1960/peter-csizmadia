#ifndef slopefit_h
#define slopefit_h

class FittingFunc;

double calc_chisq(const double* X, const double* Y, const double* W, int n,
		  FittingFunc* ff);

void slopefit(const double* X, const double* Y, const double* W, int N,
	      double A[3], double* C, int n, double epsilon, int maxit,
	      FittingFunc* ff);

#endif /* slopefit_h */
