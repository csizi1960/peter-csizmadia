/*
 * slopefit 1.2, Copyright (C) 1996-2000 Peter Csizmadia
 *
 * This program is protected under the terms of the GNU General Public
 * License (GPL) as published by the Free Software Foundation, Inc.,
 * 675 Mass Ave, Cambridge MA 02139, USA; either version 2 of the
 * License, or (at your option) any later version.
 * http://www.gnu.org/copyleft/gpl.html
 */
#ifndef EXPALPHAFF_H
#define EXPALPHAFF_H

#include "FittingFunc.h"

class ExpalphaFF: public FittingFunc {
public:
    ExpalphaFF(): FittingFunc(3) { }
    const char* getName() const { return "Expalpha"; }
    double eval(double x, const double* A) const;
    void getDerivatives(double x, int n, double* D, double* Q) const;
    virtual const char* getLabel(int i) const {
	return (i==0)? "A" : (i==1)? "T" : (i==2)? "alpha" : "NONE";
    }
    double getMin(int i) const { return (i<2)? 0.0 : -100.0; }
    double getMax(int i) const { return (i<1)? 1e20 : 100.0; }
};

#endif /* EXPALPHAFF_H */
