/*
 * slopefit 1.2, Copyright (C) 1996-2000 Peter Csizmadia
 *
 * This program is protected under the terms of the GNU General Public
 * License (GPL) as published by the Free Software Foundation, Inc.,
 * 675 Mass Ave, Cambridge MA 02139, USA; either version 2 of the
 * License, or (at your option) any later version.
 * http://www.gnu.org/copyleft/gpl.html
 */
#include <string.h> /* memcpy */
#include "FittingFunc.h"

FittingFunc::FittingFunc(int n)
{
    this->n = n;
    this->A = new double[n];
    this->delta = 1e-4;
    for(int i=0; i<n; ++i)
	this->A[i] = 0;
}

FittingFunc::~FittingFunc()
{
    delete A;
}

void FittingFunc::setParameters(const double* A)
{
    for(int i=0; i<n; ++i)
	this->A[i] = A[i];
}

void FittingFunc::getDerivatives(double x, int n, double* D, double* Q) const
{
    double* B = new double[n];
    for(int i=0; i<n; ++i) {
	memcpy(B, A, n*sizeof(B[0]));
	double f0 = eval(x, B);
	B[i] = A[i] - delta;
	double fm = eval(x, B);
	B[i] = A[i] + delta;
	double fp = eval(x, B);
	D[i] = (fp-fm)/(2*delta);
	Q[n*i+i] = (fp - 2*f0 + fm)/(delta*delta);
	for(int j=i+1; j<n; ++j) {
	    memcpy(B, A, n*sizeof(B[0]));
	    B[i] = A[i] + delta/2;
	    B[j] = A[j] - delta/2;
	    double fpm = eval(x, B);
	    B[j] = A[j] + delta/2;
	    double fpp = eval(x, B);
	    B[i] = A[i] - delta/2;
	    B[j] = A[j] - delta/2;
	    double fmm = eval(x, B);
	    B[j] = A[j] + delta/2;
	    double fmp = eval(x, B);
	    Q[n*i+j] = Q[n*j+i] = (fpp - fpm - fmp + fmm)/(delta*delta);
	}
    }
    delete B;
}
