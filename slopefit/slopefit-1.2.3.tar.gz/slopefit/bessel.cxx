#include <math.h>
#include "bessel.h"

double besselI0(double x)
{
    if(fabs(x) < 3.75) {
	const double p1=1.0, p2=3.5156229, p3=3.0899424,
	    p4=1.2067492, p5=0.2659732, p6=0.360768e-1, p7=0.45813e-2;
	double y = (x/3.75);
	y *= y;
	return p1+y*(p2+y*(p3+y*(p4+y*(p5+y*(p6+y*p7)))));
    } else {
	const double q1=0.39894228, q2=0.1328592e-1, q3=0.225319e-2,
	    q4=-0.157565e-2, q5=0.916281e-2, q6=-0.2057706e-1,
	    q7=0.2635537e-1, q8=-0.1647633e-1, q9=0.392377e-2;
	double ax = fabs(x);
	double y = 3.75/ax;
	return exp(ax)/sqrt(ax)
	    *(q1+y*(q2+y*(q3+y*(q4+y*(q5+y*(q6+y*(q7+y*(q8+y*q9))))))));
    }
}

double besselI1(double x)
{
    if(fabs(x) < 3.75) {
	const double p1=0.5, p2=0.87890594, p3=0.51498869,
	    p4=0.15084934, p5=0.2658733e-1, p6=0.301532e-2, p7=0.32411e-3;
	double y = (x/3.75);
	y *= y;
	return x*(p1+y*(p2+y*(p3+y*(p4+y*(p5+y*(p6+y*p7))))));
    } else {
	const double q1=0.39894228, q2=-0.3988024e-1,
	    q3=-0.362018e-2, q4=0.163801e-2, q5=-0.1031555e-1, q6=0.2282967e-1,
	    q7=-0.2895312e-1, q8=0.1787654e-1, q9=-0.420059e-2;
	double ax = fabs(x);
	double y = 3.75/ax;
	return exp(ax)/sqrt(ax)
	    *(q1+y*(q2+y*(q3+y*(q4+y*(q5+y*(q6+y*(q7+y*(q8+y*q9))))))));
    }
}

double besselK0(double x)
{
    if(x < 2) {
	const double p1=-0.57721566, p2=0.42278420, p3=0.23069756,
	    p4=0.3488590e-1, p5=0.262698e-2, p6=0.10750e-3, p7=0.74e-5;
	double y = x*x/4;
	return -log(x/2)*besselI0(x)
	    +p1+y*(p2+y*(p3+y*(p4+y*(p5+y*(p6+y*p7)))));
    } else {
	const double q1=1.25331414, q2=-0.7832358e-1, q3=0.2189568e-1,
	    q4=-0.1062446e-1, q5=0.587872e-2, q6=-0.251540e-2, q7=0.53208e-3;
	double y = 2/x;
	return (exp(-x)/sqrt(x))
	    *(q1+y*(q2+y*(q3+y*(q4+y*(q5+y*(q6+y*q7))))));
    }
}

double besselK1(double x)
{
    if(x < 2) {
	const double p1=1.0, p2=0.15443144, p3=-0.67278579,
	    p4=-0.18156897, p5=-0.1919402e-1, p6=-0.110404e-2, p7=-0.4686e-4;
	double y = x*x/4;
	return log(x/2)*besselI1(x) + (1/x)
	    *(p1+y*(p2+y*(p3+y*(p4+y*(p5+y*(p6+y*p7))))));
    } else {
	const double q1=1.25331414, q2=0.23498619, q3=-0.3655620e-1,
	    q4=0.1504268e-1, q5=-0.780353e-2, q6=0.325614e-2, q7=-0.68245e-3;
	double y = 2/x;
	return (exp(-x)/sqrt(x))
	    *(q1+y*(q2+y*(q3+y*(q4+y*(q5+y*(q6+y*q7))))));
    }
}

/*#include <stdlib.h>
#include <stdio.h>

int main(int argc, char* argv[])
{
    double x = (argc > 1)? atof(argv[1]) : 5.0;
    double dx = x*1e-7;
    printf("x=%.1f K0=%g K1=%g\n", x, besselK0(x), besselK1(x));
    printf("dK0/dx=%g %g\n",
        (besselK0(x+dx/2)-besselK0(x-dx/2))/dx, besselK1(x));
    printf("dK1/dx=%g %g\n",
        (besselK1(x+dx/2)-besselK1(x-dx/2))/dx, -besselK0(x)-besselK1(x)/x);
    printf("x=%.1f I0=%g I1=%g\n", x, besselI0(x), besselI1(x));
    printf("dI0/dx=%g %g\n",
        (besselI0(x+dx/2)-besselI0(x-dx/2))/dx, besselI1(x));
    printf("dI1/dx=%g %g\n",
        (besselI1(x+dx/2)-besselI1(x-dx/2))/dx, besselI0(x) - besselI1(x)/x);
    return 0;
}*/
