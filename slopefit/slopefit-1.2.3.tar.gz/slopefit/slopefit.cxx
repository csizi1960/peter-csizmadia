/*
 * slopefit 1.2.2, Copyright (C) 1996-2001 Peter Csizmadia
 *
 * This program is protected under the terms of the GNU General Public
 * License (GPL) as published by the Free Software Foundation, Inc.,
 * 675 Mass Ave, Cambridge MA 02139, USA; either version 2 of the
 * License, or (at your option) any later version.
 * http://www.gnu.org/copyleft/gpl.html
 */
#include <math.h>
#include <string.h> /* memcpy, memset */
#include "slopefit.h"
#include "FittingFunc.h"

/************************ chi-square *****************************/

/**
 * Calculates the chi square for a fit.
 */
double calc_chisq(const double* X, const double* Y, const double* W, int n,
		  FittingFunc* ff)
{
    double chisq = 0;
    for(int i = 0; i < n; ++i) {
	double d = Y[i] - ff->eval(X[i]);
	chisq += W[i]*d*d;
    }
    return chisq;
}

/************************ matrix functions ***********************/

static void swaprows(int n, double* A, int i, int j)
{
    double* T = new double[n];
    memcpy(T, A+i*n, n*sizeof(double));
    memcpy(A+i*n, A+j*n, n*sizeof(double));
    memcpy(A+j*n, T, n*sizeof(double));
    delete[] T;
}

static void matminor(int n, double* A, int k, int l, double* B)
{
    for(int i = 0; i < n; ++i) if(i != k) {
	for(int j = 0; j < n; ++j) if(j != l)
	    B[(n-1)*((i<k)? i:i-1) + ((j<l)? j:j-1)] = A[n*i+j];
    }
}

static double matdet(int n, double* A)
{
    if(n<2)
	return A[0];
    else {
	int i;
	double sign = 1;
	double det;
	double* B = new double[n*n];
	double* C = new double[(n-1)*(n-1)];
	memcpy(B, A, n*n*sizeof(B[0]));
	for(i = 0; i < n && B[n*i+0]==0; ++i);
	if(i > 0 && i < n) {
	    swaprows(n, B, 0, i);
	    sign = -sign;
	} else if(i == n) {
	    delete[] B;
	    delete[] C;
	    return 0.0;
	}
	for(i = 1; i < n; ++i) {
	    double q = B[n*i+0] / B[n*0+0];
	    for(int j = 0; j < n; ++j)
		B[n*i+j] -= q*B[n*0+j];
	}
	matminor(n, B, 0, 0, C);
	det = sign*B[n*0+0]*matdet(n-1, C);
	delete[] B;
	delete[] C;
	return det;
    }
}

static void matinv(int n, double* U, double* V)
{
    double* A = new double[n*n];
    double* B = new double[n*n];
    for(int i = 0; i < n; ++i) {
	int j;
	for(j=0; j<n; ++j) {
	    A[n*i+j] = U[n*i+j];
	    B[n*i+j] = (i==j)? 1 : 0;
	}
    }
    for(int i = 0; i < n; ++i) {
	int j;
	for(j = i; j < n && A[n*j+i] == 0; ++j);
	if(j > i && j < n) {
	    swaprows(n, A, i, j);
	    swaprows(n, B, i, j);
	} else
	    if(j == n) {
		memset(V, 0, n*n*sizeof(double));
		delete[] A;
		delete[] B;
		return;
	    }
	for(j = i + 1; j < n; ++j) {
	    double q = A[n*j+i]/A[n*i+i];
	    for(int k = 0; k < n; ++k) {
		A[n*j+k] -= q*A[n*i+k];
		B[n*j+k] -= q*B[n*i+k];
	    }
	}
    }
    for(int i = 0; i < n; ++i) {
	for(int j = n - 1; j >= 0; --j) {
	    V[n*j+i] = B[n*j+i];
	    for(int k = j + 1; k < n; ++k)
		V[n*j+i] -= A[n*j+k]*V[n*k+i];
	    V[n*j+i] /= A[n*j+j];
	}
    }
    delete[] A;
    delete[] B;
}

static void matvecmult(int n, double* U, double* u, double* v)
{
    for(int i = 0; i < n; ++i) {
	v[i] = 0;
	for(int j = 0; j < n; ++j)
	    v[i] += U[n*i+j]*u[j];
    }
}

/************************ fitting ********************************/

/**
 * 0th approximation: fit the linearized function.
 */
static void slopefit0(const double* X, const double* Y, const double* W, int N,
		      double lA[3], int n)
{
    double U[3*3], V[3*3], u[3];
    memset(u, 0, sizeof(u));
    memset(U, 0, sizeof(U));
    for(int i = 0; i < N; ++i) {
	double x = X[i];
	double y = Y[i];
	double lnx = log(x);
	double lny = log(y);
	double w = W[i]*y*y;
	U[n*0+0] += w;
	if(n > 1) {
	    U[n*0+1] -= w*x;
	    U[n*1+1] -= w*x*x;
	    if(n > 2) {
		U[n*0+2] += w*lnx;
		U[n*1+2] += w*x*lnx;
		U[n*2+2] += w*lnx*lnx;
	    }
	}
	switch(n) {
	    case 1: /* lA[1]==beta and lA[2]==alpha fix*/
		u[0] += w*(lny + lA[1]*x - lA[2]*lnx);
		break;
	    case 2: /* lA[2]==alpha fix */
		u[0] += w*(lny - lA[2]*lnx);
		u[1] += w*x*(lny - lA[2]*lnx);
		break;
	    case 3: /* no fix parameters */
		u[0] += w*lny;
		u[1] += w*x*lny;
		u[2] += w*lnx*lny;
		break;
	}
    }
    if(n > 1) {
	U[n*1+0] = -U[n*0+1];
	if(n > 2) {
	    U[n*2+0] = U[n*0+2];
	    U[n*2+1] = -U[n*1+2];
	}
    }
    matinv(n, U, V);
    matvecmult(n, V, u, lA);
/*    *variance_lnA_return = V11;*/
/*    *variance_beta_return = V22;*/
/*    *variance_alpha_return = V33;*/
}

/**
 * Calculates the G1 gradient vector and the G2 matrix of second derivatives.
 */
static void
slopeG(const double* X, const double* Y, const double* W, int N,
       double* G1, double* G2, int n, FittingFunc* ff)
{
    double D[3], Q[9];
    memset(G1, 0, n*sizeof(double));
    memset(G2, 0, n*n*sizeof(double));
    for(int i = 0; i < N; ++i) {
	double w = 2*W[i];
	double delta = ff->eval(X[i]) - Y[i];
	ff->getDerivatives(X[i], n, D, Q);
	for(int j = 0; j < n; ++j) {
	    G1[j] += w*delta*D[j];
	    for(int k = 0; k < n; ++k) {
		G2[n*j+k] += w*(D[j]*D[k] + delta*Q[n*j+k]);
	    }
	}
    }
}

/**
 * Finds the minimum of the chi square with Newton's method.
 */
static bool find_min(double *h, const double* X, const double* Y,
		     const double* W,
		     int N, double A[3], double* C, int n, double epsilon,
		     int maxit, FittingFunc* ff)
{
    memset(C, 0, n*n*sizeof(C[0]));
    double G1[3], G2[3*3], H2[3*3];
    *h = calc_chisq(X, Y, W, N, ff);
    for(int i = 0; i < maxit || maxit < 0; ++i) {
	double A0[3], D0[3], D[3];
	double h0 = *h;
	double detG2;
	memcpy(A0, A, sizeof(A0));
	ff->setParameters(A);
	slopeG(X, Y, W, N, G1, G2, n, ff);
	detG2 = matdet(n, G2);
	matinv(n, G2, H2);

	double qmin = 1.0;
	for(int j = 0; j < n; ++j) {
	    D0[j] = 0;

	    for(int k = 0; k < n; ++k) {
		D0[j] -= 0.5*H2[n*j+k]*G1[k];
		/* The factor 0.5 is for safety. It halves the speed of
		   convergence, but without it, convergence may change to
		   divergence in some cases.
		 */
	    }
	    if(A0[j]+D0[j] <= ff->getMin(j)) {
		double q = 0.5*(ff->getMin(j) - A0[j])/D0[j];
		if(q < qmin)
		    qmin = q;
	    }
	    if(A0[j]+D0[j] >= ff->getMax(j)) {
		double q = 0.5*(ff->getMax(j) - A0[j])/D0[j];
		if(q < qmin)
		    qmin = q;
	    }
	}
	for(int j = 0; j < n; ++j) {
	    D[j] = D0[j]*qmin;
	    A[j] = A0[j] + D[j];
	}
	ff->setParameters(A);
	if((*h = calc_chisq(X, Y, W, N, ff)) > h0) {
	    double Ap[3], Am[3];
	    double hp, hm;
	    for(int k = 0; k < 10; ++k) {
		for(int j = 0; j < n; ++j) {
		    D[j] /= 2;
		    Ap[j] = A0[j] + D[j];
		    Am[j] = A0[j] - D[j];
		    if(Ap[j] >= ff->getMax(j))
			Ap[j] = (A0[j] + ff->getMax(j))/2;
		    if(Ap[j] <= ff->getMin(j))
			Ap[j] = (A0[j] + ff->getMin(j))/2;
		    if(Am[j] >= ff->getMax(j))
			Am[j] = (A0[j] + ff->getMax(j))/2;
		    if(Am[j] <= ff->getMin(j))
			Am[j] = (A0[j] + ff->getMin(j))/2;
		}
		for(int j = n; j < 3; ++j)
		    Ap[j] = Am[j] = A[j]; /* fix parameters */
		ff->setParameters(Ap);
		hp = calc_chisq(X, Y, W, N, ff);
		ff->setParameters(Am);
		hm = calc_chisq(X, Y, W, N, ff);
		if(hp <= h0 || hm <= h0)
		    break;
	    }
	    if(hp < *h || hm < *h) {
		if(hp < hm) {
		    *h = hp;
		    memcpy(A, Ap, n*sizeof(A[0]));
		} else {
		    *h = hm;
		    memcpy(A, Am, n*sizeof(A[0]));
		}
	    } else if(detG2>=0) {
		break;
	    } else {
		return false;
	    }
	}
	if(fabs(h0-*h) < sqrt(h0)*epsilon) {
	    if(detG2 >= 0)
		break;
	    else
		return false;
	}
    }
    for(int i = 0; i < n; ++i) {
	for(int j = 0; j < n; ++j)
	    C[n*i+j] = 2*H2[n*i+j];
    }
    return true;
}

/**
 * Finds the minimum of the chi square with Newton's method.
 */
void slopefit(const double* X, const double* Y, const double* W, int N,
	      double A[3], double* C, int n, double epsilon, int maxit,
	      FittingFunc* ff)
{
    double lA[3]; /* lnA, beta, alpha */
    double h;
    lA[2] = A[2]; /* alpha */
    if(n < 2)
	lA[1] = 1/A[1]; /* beta */

    /* 0th approximation */
    if(!strcmp(ff->getName(), "Expalpha")) {
    	slopefit0(X, Y, W, N, lA, n);
    } else {
    	slopefit0(X, Y, W, N, lA, 2);
    }

    A[0] = exp(lA[0]); /* A */
    if(n > 1) {
	A[1] = 1/lA[1]; /* t */
	if(n > 2)
	    A[2] = lA[2]; /* alpha */
    }
    ff->setParameters(A);
    h = calc_chisq(X, Y, W, N, ff);
    if((!strcmp(ff->getName(), "ExpSh") || !strcmp(ff->getName(), "SR")
	|| !strcmp(ff->getName(), "K0I0")) && n == 3) {
	double Am[3], Cm[9];
	memcpy(Am, A, 3*sizeof(A[0]));
	double hmin = 0;
	for(int i = 1; i < 10; ++i) {
	    memcpy(A, Am, 3*sizeof(A[0]));
	    A[2] = i/10.0;
	    for(n = 2; n <= 3; ++n) {
    	    	find_min(&h, X, Y, W, N, A, C, n, epsilon, maxit, ff);
	    	if((i == 1 && n == 2) || h < hmin) {
		    memcpy(Am, A, 3*sizeof(A[0]));
		    memcpy(Cm, C, 9*sizeof(C[0]));
		    hmin = h;
		}
	    }
	}
	memcpy(A, Am, 3*sizeof(A[0]));
	memcpy(C, Cm, 9*sizeof(C[0]));
    } else
	find_min(&h, X, Y, W, N, A, C, n, epsilon, maxit, ff);
}
