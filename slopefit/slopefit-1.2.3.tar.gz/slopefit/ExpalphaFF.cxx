/*
 * slopefit 1.2, Copyright (C) 1996-2000 Peter Csizmadia
 *
 * This program is protected under the terms of the GNU General Public
 * License (GPL) as published by the Free Software Foundation, Inc.,
 * 675 Mass Ave, Cambridge MA 02139, USA; either version 2 of the
 * License, or (at your option) any later version.
 * http://www.gnu.org/copyleft/gpl.html
 */
#include <math.h>
#include "ExpalphaFF.h"

double ExpalphaFF::eval(double x, const double* A) const
{
    return A[0]*exp(A[2]*log(x) - x/A[1]);
}

void ExpalphaFF::getDerivatives(double x, int n, double* D, double* Q) const
{
    double logx = log(x);
    D[0] = exp(A[2]*logx - x/A[1]);
    Q[n*0+0] = 0;
    if(n > 1) {
	double xtt = x/(A[1]*A[1]);
	double dadt = D[0]*xtt;
    	D[1] = A[0]*dadt;
	Q[n*1+0] = Q[n*0+1] = dadt;
	Q[n*1+1] = D[1]*(xtt - 2/A[1]);
	if(n > 2) {
    	    D[2] = A[0]*D[0]*logx;
	    Q[n*2+0] = Q[n*0+2] = D[0]*logx;
	    Q[n*2+1] = Q[n*1+2] = A[0]*dadt*logx;
	    Q[n*2+2] = A[0]*D[0]*logx*logx;
	}
    }
}
