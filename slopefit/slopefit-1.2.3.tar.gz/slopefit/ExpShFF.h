/*
 * slopefit 1.2, Copyright (C) 1996-2000 Peter Csizmadia
 *
 * This program is protected under the terms of the GNU General Public
 * License (GPL) as published by the Free Software Foundation, Inc.,
 * 675 Mass Ave, Cambridge MA 02139, USA; either version 2 of the
 * License, or (at your option) any later version.
 * http://www.gnu.org/copyleft/gpl.html
 */
#ifndef EXPSHFF_H
#define EXPSHFF_H

#include "FittingFunc.h"

class ExpShFF: public FittingFunc {
public:
    ExpShFF(): FittingFunc(3) { }
    const char* getName() const { return "ExpSh"; }
    double eval(double x, const double* A) const;
    void getDerivatives(double x, int n, double* D, double* Q) const;
    virtual const char* getLabel(int i) const {
	return (i==0)? "A" : (i==1)? "T" : (i==2)? "v" : "NONE";
    }
    double getMin(int i) const { return 0.0; }
    double getMax(int i) const { return (i==0)? 1e20 : (i==1)? 100.0 : 1.0; }
};

#endif /* EXPSHFF_H */
