/*
 * slopefit 1.2.3, Copyright (C) 1996-2001 Peter Csizmadia
 *
 * This program is protected under the terms of the GNU General Public
 * License (GPL) as published by the Free Software Foundation, Inc.,
 * 675 Mass Ave, Cambridge MA 02139, USA; either version 2 of the
 * License, or (at your option) any later version.
 * http://www.gnu.org/copyleft/gpl.html
 */
#include <math.h>
#include <stdio.h>
#include <stdlib.h> /* atof */
#include <string.h> /* memcpy, memset */
#include "slopefit.h"
#include "ExpalphaFF.h"
#include "K1mtFF.h"
#include "ExpShFF.h"
#include "SiemensRasmussenFF.h"
#include "K0I0FF.h"

#define MAXPOINTS 1000
#define MAXLINE   256

#define MAXIT     -1
#define EPSILON   1e-6

const char* strhelp1="\
dN/mtdmt=A*exp(-mt/T)*(mt/m)^alpha fitting / Peter Csizmadia / 1996-2001\n\
Usage:\tslopefit [options] [format] [files...]\n\
Output columns: y T alpha A s_T s_alpha s_A N chi^2 z(chi^2)\n\
  (s_T, s_alpha, s_A: standard deviations; N: number of points)\n\
Comment lines begin with '#' or ';'.\n\
Options\n\
  -h  help\n\
  -v  verbose\n\
  -a <alpha or v>  set alpha or v (do not fit it)\n\
  -t <T>           set T          (do not fit it)\n\
  -m <mass>   set mass (default=1)\n\
  -F <format string>\n\
  -I <maxit>\tmaximum iteration number\n\
  --write <file> <mt-m min> <dmt> <mt-m max>   save points of fitting curve\n\
  --append <file> <mt-m min> <dmt> <mt-m max>  append fitting curve to file\n\
  --ymin <min> --ymax <max>       min < y < max data sets only\n\
  --mtmmin <min> --mtmmax <max>   min < mt-m < max data points only\n\
  --mtmin <min>  --mtmax <max>    min < mt < max data points only\n\
  --ptmin <min>  --ptmax <max>    min < pt < max data points only\n\
Other fitting methods:  ( a=gamma*mt/T, b=gamma*v*pt/T, gamma=1/sqrt(1-v^2) )\n\
  --k1mt  A*mt*K1(mt/T)                       Boltzmann\n\
  --expsh A*mt*sinh(b)/b*exp(-a)              Spher.symm & const.radial flow\n\
  --sr    A*((1+a)*sinh(b)/b-cosh(b))*exp(-a) Siemens-Rasmussen\n\
  --k0i0  A*mt*K0(a)*I0(b)                    Cyl.symm. & const.transv.flow\n\
Format strings\n\
  \"[<rapidity> ]<transverse momentum> <particle number> <std.deviation>\"\n\
  <rapidity>:            y\n\
  <transverse momentum>: pt pt/m mt mt-m\n\
  <particle number>:     dn/mtdmt dn/ptdpt dn/dmt dn/dpt mdn/dmt mdn/dpt\n\
  <standard deviation>:  s\n";

const char* strhelp2="\
Default errors: s=sqrt(N)\n\
Examples\n\
  slopefit -m 0.77 incoming/rho.ymtm\n\
  slopefit -vm 0.1396 .ymtm outgoing/alcor1.+211\n\
  slopefit -vm 0.1396 pi.dat -F \"mt-m dn/mtdmt s\"\n";

struct DataFormat {
    char* ext;
    char* fmt_str;
    char* comment;
};

struct OutFile {
    OutFile() {
	f = NULL;
	fname = NULL;
	mode[0] = 0;
	xmin = dx = xmax = 0;
    }
    void open() { f = fopen(fname, mode); }
    ~OutFile() { if(f != NULL) fclose(f); }
    char* fname;
    char mode[4];
    double xmin;
    double dx;
    double xmax;
    FILE* f;
};

const DataFormat data_formats[]={
{"pt",   "pt dn/ptdpt",       "experimental data"},
{"mtm",  "mt-m dn/mtdmt",     "experimental data"},
{"ymtm", "y mt-m dn/mtdmt s", "alcrate3, coalrate, m-detect output"},
{"",     "",                  ""}};

static void fprintin7(FILE* f, double x)
{
    if(x<0.00010)
	fprintf(f, "%.1e", x);
    else if(x<10)
	fprintf(f, "%.5f", x);
    else if(x<100)
	fprintf(f, "%.4f", x);
    else if(x<1000)
	fprintf(f, "%.3f", x);
    else if(x<10000)
	fprintf(f, "%.2f", x);
    else if(x<100000)
	fprintf(f, "%.1f", x);
    else
	fprintf(f, "%.1e", x);
}

static void printin7(double x)
{
    fprintin7(stdout, x);
}

static int read_data(double m, double* py, int* y_set,
		     double* X, double* Y, double* W, int* W_set,
		     const char* fmt_str, FILE* f, double xmin, double xmax)
{
    char buf[MAXLINE];
    int Winf[MAXPOINTS];
    int infweighted = 0;
    int n = 0;
    *y_set = 0;
    *W_set = 0;
    memset(Winf, 0, sizeof(Winf));
    while(fgets(buf, MAXLINE, f) == buf && n < MAXPOINTS) {
	int i;
	char desc[100]="";
	char* fmt_p = (char*)fmt_str;
	char* buf_p = buf;
	char* buf_q;
	int Xn_set = 0;
	int Yn_set = 0;
	double J = 0;
	if(buf[0]=='#' || buf[0]==';')
	    continue;
	for(i=1; ; ++i) {
	    int r = sscanf(fmt_p, "%s", desc);
	    if(r>0 && *desc != '\0') {
		double x = strtod(buf_p, &buf_q);
		if(buf_q==0 || buf_q==buf_p) {
		    if(i > 1) {
			fprintf(stderr, "no number for descriptor #%d "
					"- \"%s\" - in file\n", i, desc);
			exit(1);
		    } else /* empty line */
			goto out;
		}
		if(!strcmp(desc, "y")) {
		    if(n==0) {
			*py = x;
			*y_set = 1;
		    } else if(fabs(*py - x) > 1e-9) {
			fprintf(stderr,
				"y=%g changed to %g before empty line\n",
				*py, x);
			exit(1);
		    }
		} else if(!strcmp(desc, "mt/m")) {
		    X[n] = x;
		    ++Xn_set;
		} else if(!strcmp(desc, "mt")) {
		    X[n] = x/m;
		    ++Xn_set;
		} else if(!strcmp(desc, "mt-m")) {
		    X[n] = 1 + x/m;
		    ++Xn_set;
		} else if(!strcmp(desc, "pt/m")) {
		    X[n] = sqrt(1 + x*x);
		    ++Xn_set;
		} else if(!strcmp(desc, "pt")) {
		    X[n] = sqrt(1 + x*x/(m*m));
		    ++Xn_set;
		} else if(!strcmp(desc, "dn/mtdmt") ||
			  !strcmp(desc, "dn/ptdpt")) {
		    J = 1;
		    Y[n] = J*x;
		    Yn_set = 1;
		} else if(!strcmp(desc, "dn/dmt")) {
		    if(!Xn_set) {
			fprintf(stderr, "mt must precede dn/dmt\n");
			exit(1);
		    }
		    J = 1/(m*X[n]);
		    Y[n] = J*x;
		    Yn_set = 1;
		} else if(!strcmp(desc, "dn/dpt")) {
		    if(!Xn_set) {
			fprintf(stderr, "mt must precede dn/dpt\n");
			exit(1);
		    }
		    J = 1/(m*sqrt(X[n]*X[n]-1));
		    Y[n] = J*x;
		    Yn_set = 1;
		} else if(!strcmp(desc, "mdn/dmt")) {
		    if(!Xn_set) {
			fprintf(stderr, "mt must precede mdn/dmt\n");
			exit(1);
		    }
		    J = 1/(m*m*X[n]);
		    Y[n] = J*x;
		    Yn_set = 1;
		} else if(!strcmp(desc, "mdn/dpt")) {
		    if(!Xn_set) {
			fprintf(stderr, "mt must precede mdn/dpt\n");
			exit(1);
		    }
		    J = 1/(m*m*sqrt(X[n]*X[n]-1));
		    Y[n] = J*x;
		    Yn_set = 1;
		} else if(!strcmp(desc, "s")) {
		    double s = J*x; /* standard deviation of Y[n] */
		    if(!Yn_set) {
			fprintf(stderr, "dn/mtdmt must precede s\n");
			exit(1);
		    }
		    if(s != 0)
			W[n] = 1/(s*s);
		    else {
			if(Y[n] > 0) {
			    W[n] = 1;
			    Winf[n] = 1;
			    infweighted = 1;
			} else
			    W[n] = 0;
		    }
		    if(n == 0)
			*W_set = 1;
		} else {
		    fprintf(stderr, "unknown descriptor \"%s\"\n", desc);
		    exit(1);
		}
		fmt_p += strlen(desc);
		if(*fmt_p==' ')
		    ++fmt_p;
		buf_p = buf_q;
	    } else
		break;
	}
	if(!Xn_set) {
	    fprintf(stderr, "mt column required\n");
	    exit(1);
	}
	if(!Yn_set) {
	    fprintf(stderr, "dn/mtdmt column required\n");
	    exit(1);
	}
	if(X[n] <= 0) {
	    fprintf(stderr, "mt must be positive\n");
	    exit(1);
	}
	if(X[n] >= xmin && X[n] <= xmax && Y[n] > 0)
	    ++n;
    }
    out:
    if(infweighted) { /* there are points with zero standard deviation */
	int i;
	fprintf(stderr,
		"WARNING: removing points with nonzero standard deviation\n");
	for(i=0; i<n; ++i)
	    if(!Winf[i]) {
		memmove(X+i, X+i+1, (n-i-1)*sizeof(X[0]));
		memmove(Y+i, Y+i+1, (n-i-1)*sizeof(Y[0]));
		memmove(W+i, W+i+1, (n-i-1)*sizeof(W[0]));
		memmove(Winf+i, Winf+i+1, (n-i-1)*sizeof(Winf[0]));
		--n;
		--i;
	    }
    }
    return n;
}

/************************ chi-square *****************************/

/**
 * Converts chi square to Gaussian distribution.
 */
static double Z_chisq(double h, int df)
{
   if(df > 0) {
   	double w = 2.0 / 9.0 / df;
   	return (pow(h/df, 1/3.0) - (1-w)) / sqrt(w);
   } else
	return 0.0;
}

/******************* command line, main **************************/

static int is_simple_name(char* p)
{
    while(*p != '\0') {
	if(!((*p >= 'a' && *p <= 'z') || (*p >= 'A' && *p <= 'Z') ||
	     (*p >= '0' && *p <= '9')))
	    return 0;
	++p;
    }
    return 1;
}

static char* recognize_format(const char* ext, char* s)
{
    DataFormat* p = (DataFormat*) data_formats;
    while(strcmp(ext, p->ext) && *p->fmt_str!='\0')
	++p;
    strcpy(s, p->fmt_str);
    return s;
}

static void print_help()
{
    DataFormat* p = (DataFormat*) data_formats;
    printf(strhelp1);
    printf("Known formats\n");
    while(*p->fmt_str != '\0') {
	printf("  .%-6s\t-F \"%s\"\t%s\n", p->ext, p->fmt_str, p->comment);
	++p;
    }
    printf(strhelp2);
}

static int
parse_command_line(int argc, char* argv[], int* argi, int* quit,
		   char** fname, int* verbose, char* fmt_str, int* fmt_set,
		   int* nfitpars, double* val_alpha,
		   double* val_T, double* m, int* maxit, FittingFunc** ff,
		   double* ymin, double* ymax, double* mtmmin, double* mtmmax,
		   OutFile* ofile)
{
    int setfmt_F = 0;
    int setfmt_dot = 0;
    double mtmin = -1;
    double mtmax = -1;
    double ptmin = -1;
    double ptmax = -1;
    while(*argi < argc) {
	char* p = argv[*argi];
	if(!strcmp(p, "--write") || !strcmp(p, "--append")) {
	    ofile->fname = argv[++(*argi)];
	    ofile->xmin = atof(argv[++(*argi)]);
	    ofile->dx = atof(argv[++(*argi)]);
	    ofile->xmax = atof(argv[++(*argi)]);
	    strcpy(ofile->mode, strcmp(p, "--append")? "w" : "a");
	} else if(!strcmp(p, "--k1mt")) {
	    delete *ff;
	    *ff = new K1mtFF;
	    *nfitpars = 2;
	} else if(!strcmp(p, "--expsh")) {
	    delete *ff;
	    *ff = new ExpShFF;
	    if(*nfitpars > 2)
		*val_alpha = 0.1;
	} else if(!strcmp(p, "--sr")) {
	    delete *ff;
	    *ff = new SiemensRasmussenFF;
	    if(*nfitpars > 2)
		*val_alpha = 0.1;
	} else if(!strcmp(p, "--k0i0")) {
	    delete *ff;
	    *ff = new K0I0FF;
	    (*ff)->setDelta(0.01);
	    if(*nfitpars > 2)
		*val_alpha = 0.1;
	} else if(*p == '-') {
	    ++p;
	    while(*p != 0) {
		switch(*(p++)) {
		case '-':
		    if(!strcmp(p, "help")) {
			print_help();
			*quit=1;
			return 0;
		    } else if(!strcmp(p, "ymin")) {
			*ymin = atof(argv[++(*argi)]);
			p += strlen(p);
		    } else if(!strcmp(p, "ymax")) {
			*ymax = atof(argv[++(*argi)]);
			p += strlen(p);
		    } else if(!strcmp(p, "mtmmin")) {
			*mtmmin = atof(argv[++(*argi)]);
			p += strlen(p);
		    } else if(!strcmp(p, "mtmmax")) {
			*mtmmax = atof(argv[++(*argi)]);
			p += strlen(p);
		    } else if(!strcmp(p, "mtmin")) {
			mtmin = atof(argv[++(*argi)]);
			p += strlen(p);
		    } else if(!strcmp(p, "mtmax")) {
			mtmax = atof(argv[++(*argi)]);
			p += strlen(p);
		    } else if(!strcmp(p, "ptmin")) {
			ptmin = atof(argv[++(*argi)]);
			p += strlen(p);
		    } else if(!strcmp(p, "ptmax")) {
			ptmax = atof(argv[++(*argi)]);
			p += strlen(p);
		    } else {
			fprintf(stderr, "%s: unknown option\n", argv[*argi]);
			*quit=1;
			return 1;
		    } break;
		case 'h': case '?': print_help(); *quit=1; return 0;
		case 'v': *verbose=1; break;
		case 'F': strcpy(fmt_str, argv[++(*argi)]); setfmt_F=1; break;
		case 'a':
		    *val_alpha=atof(argv[++(*argi)]);
		    if(*nfitpars > 2)
			*nfitpars = 2;
		    break;
		case 't': *val_T=atof(argv[++(*argi)]); *nfitpars = 1; break;
		case 'm': *m=atof(argv[++(*argi)]); break;
		case 'I': *maxit=atoi(argv[++(*argi)]); break;
		default:
		    fprintf(stderr, "slopefit: unknown options -%c\n", *(p-1));
		}
	    }
	} else if(*p == '+') {
	    ++p;
	    while(*p != 0) {
		switch(*(p++)) {
		default:
		    fprintf(stderr, "slopefit: unknown options +%c\n", *(p-1));
		}
	    }
	} else if(*p == '.' && is_simple_name(p+1)) {
	    setfmt_dot=1;
	    recognize_format(p+1, fmt_str);
	    if(*fmt_str=='\0') {
		fprintf(stderr, "cannot recognize format `%s'\n", p);
		return 1;
	    }
	} else if(*fname=='\0') {
	    char* ext;
	    *fname = p;
	    for(ext=*fname+strlen(*fname); ext>*fname && *ext!='.'; --ext);
	    if(*ext != 0)
		++ext;
	    if(*fmt_str=='\0')
		recognize_format(ext, fmt_str);
	    break; // stop command line after filename
	}
	++(*argi);
    }
    if(*fmt_str=='\0') {
	fprintf(stderr, "could not recognize format for file `%s'\n",
		(*fname == (char*)0)? "" : *fname);
	return 1;
    }
    if(setfmt_F && setfmt_dot) {
	fprintf(stderr, "do not set the file format in two ways "
			"at the same time\n");
	return 1;
    }
    if(setfmt_F || setfmt_dot) {
	*fmt_set = 1;
    }
    if(mtmin >= 0)
	*mtmmin = mtmin - (*m);
    if(mtmax >= 0)
	*mtmmax = mtmax - (*m);
    if(ptmin >= 0)
	*mtmmin = sqrt((*m)*(*m) + ptmin*ptmin) - (*m);
    if(ptmax >= 0)
	*mtmmax = sqrt((*m)*(*m) + ptmax*ptmax) - (*m);
    return 0;
}

static void
set_weights(const double* X, const double* Y, double* W, int n)
{
    int i;
    for(i=0; i<n; ++i) {
	double x = X[i];
	double y = Y[i];
	if(x > 0 && y > 0) {
	    double dx = (i==0)? X[1]-x : (i==n-1)? x-X[n-2] : (X[i+1]-X[i-1])/2;
	    double variance = Y[i]*x*dx; /* Poisson distribution */
	    W[i] = 1/variance;
	} else
	    W[i] = 0;
    }
}

static int
read_fit_write(FILE* file, char* fmt_str,
	       int nfitpars, double val_alpha, double val_T, double m,
	       double* y, double epsilon, int maxit, FittingFunc* ff,
	       double ymin, double ymax, double mtmmin, double mtmmax,
	       OutFile* ofile)
{
    int k = 0;
    while(!feof(file) && k<MAXPOINTS) {
	int y_set;
	double X[MAXPOINTS]; /* independent variable */
	double Y[MAXPOINTS]; /* measured or Monte Carlo-computed data */
	double W[MAXPOINTS]; /* weights for the fit */
	int W_set;
	int N = read_data(m, &y[k], &y_set, X, Y, W, &W_set,
			  fmt_str, file, 1+mtmmin/m, 1+mtmmax/m);
	int force_optimal_chisq = !W_set;
	if(!W_set)
	    set_weights(X, Y, W, N);
	if(!y_set)
	    y[k] = 0;
	if(y[k] < ymin || y[k] > ymax)
	    continue;
	if(N > 0) {
	    double A[3] = {0.0, 0.0, 0.0};
	    double sigma[3] = {0.0, 0.0, 0.0};
	    double chisq;
	    int df;
	    if(N >= nfitpars) {
		int i;
		double C[3*3];
		A[2] = val_alpha;
		A[1] = val_T/m;
		slopefit(X, Y, W, N, A, C, nfitpars, epsilon, maxit, ff);
		for(i=0; i<nfitpars; ++i)
		    sigma[i] = sqrt(C[nfitpars*i + i]);
	    }
	    df = N - nfitpars;
	    ff->setParameters(A);
	    chisq = calc_chisq(X, Y, W, N, ff);
	    if(force_optimal_chisq) {
		int i;
		double x = sqrt(df/chisq);
		chisq = df;
		for(i=0; i<nfitpars; ++i)
		    sigma[i] *= x;
	    }
	    printf("%.3f\t", y[k]);
	    printin7(m*A[1]);
	    if(ff->getMin(2) >= 0 && ff->getMax(2) <= 1)
	    	printf("\t%.5f\t", A[2]);
	    else
		printf("\t%+.4f\t", A[2]);
	    printin7(A[0]);
	    printf("\t%.1e\t%.1e\t%.1e", m*sigma[1], sigma[2], sigma[0]);
	    printf("\t%d\t%.1f\t%+.3f\n", N, chisq, Z_chisq(chisq, df));
	    if(ofile->fname != NULL) {
		double dx = ofile->dx;
		if(k > 0)
		    fprintf(ofile->f, "\n");
		for(double z=ofile->xmin; z<ofile->xmax+dx/2; z+=dx) {
		    double x = 1+z/m;
		    double y = ff->eval(x);
		    fprintf(ofile->f, "%.4f %e\n", z, y);
		}
	    }
	    ++k;
	} else {
	    printf("\n");
	    fflush(stdout);
	    break;
	}
    }
    return k;
}

int
main(int argc, char* argv[])
{
    FILE* file = stdin;
    int quit = 0;
    int verbose = 0;
    char fmt_str[100]="";
    int fmt_set = 0;
    double y[MAXPOINTS];
    double m = 1;
    int nfitpars = 3;
    double val_alpha = 0;
    double val_T = 0;
    double epsilon = EPSILON;
    int maxit = MAXIT;
    double ymin = -1e20;
    double ymax = 1e20;
    double mtmmin = -1;
    double mtmmax = 1e30;
    int headerWritten = 0;
    OutFile ofile;
    for(int i = 1; i < argc; ++i) {
	char* fname = 0;
	FittingFunc* ff = new ExpalphaFF;
	if(!fmt_set)
	    fmt_str[0] = '\0';
	if(parse_command_line(argc, argv, &i, &quit, &fname, &verbose,
		    fmt_str, &fmt_set,
		    &nfitpars, &val_alpha, &val_T, &m, &maxit, &ff,
		    &ymin, &ymax, &mtmmin, &mtmmax, &ofile))
	{
	    delete ff;
	    return 1;
	}
	if(quit) {
	    delete ff;
	    return 0;
	}
	if(verbose) {
	    if(!headerWritten) {
		printf("# y\t%s\t%s\t%s\ts_%s\ts_%s\ts_%s\tN\tchi^2\tz\n",
			ff->getLabel(1), ff->getLabel(2), ff->getLabel(0),
			ff->getLabel(1), ff->getLabel(2), ff->getLabel(0));
		headerWritten = 1;
	    }
	}
	if(fname != 0)
	    if((file = fopen(fname, "r")) == 0) {
		fprintf(stderr, "%s: cannot open file '%s'\n", argv[0], fname);
		delete ff;
		return 1;
	    }
	if(ofile.fname != NULL)
	    ofile.open();
	for(;;) {
	    int n = read_fit_write(file, fmt_str, nfitpars, val_alpha, val_T,
		    m, y, epsilon, maxit, ff, ymin, ymax, mtmmin, mtmmax,
		    &ofile);
	    if(n < 0) {
		if(fname != 0)
		    fclose(file);
		delete ff;
		return 1;
	    } else if(n > 0) {
		if(verbose)
		    printf("# m=%g, n=%d\n", m, n);
	    } else
		break;
	}
	if(fname != 0)
	    fclose(file);
	delete ff;
    }
    return 0;
}
