/*
 * slopefit 1.2, Copyright (C) 1996-2000 Peter Csizmadia
 *
 * This program is protected under the terms of the GNU General Public
 * License (GPL) as published by the Free Software Foundation, Inc.,
 * 675 Mass Ave, Cambridge MA 02139, USA; either version 2 of the
 * License, or (at your option) any later version.
 * http://www.gnu.org/copyleft/gpl.html
 */
#ifndef FITTINGFUNC_H
#define FITTINGFUNC_H

class FittingFunc {
public:
    FittingFunc(int n);
    virtual ~FittingFunc();
    void setParameters(const double* A);
    virtual double eval(double x, const double* A) const =0;
    double eval(double x) const { return eval(x, this->A); }
    virtual void getDerivatives(double x, int n, double* D, double* Q) const;
    void setDelta(double delta) { this->delta = delta; }
    double getDelta(double delta) { return delta; }
    virtual const char* getLabel(int i) const=0;
    virtual double getMin(int i) const =0;
    virtual double getMax(int i) const =0;
    virtual const char* getName() const =0;
protected:
    double* A;
private:
    int n;
    double delta;
};

#endif /* FITTINGFUNC_H */
