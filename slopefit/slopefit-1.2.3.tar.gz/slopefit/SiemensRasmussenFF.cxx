/*
 * slopefit 1.2, Copyright (C) 1996-2000 Peter Csizmadia
 *
 * This program is protected under the terms of the GNU General Public
 * License (GPL) as published by the Free Software Foundation, Inc.,
 * 675 Mass Ave, Cambridge MA 02139, USA; either version 2 of the
 * License, or (at your option) any later version.
 * http://www.gnu.org/copyleft/gpl.html
 */
#include <math.h>
#include "SiemensRasmussenFF.h"

double SiemensRasmussenFF::eval(double x, const double* A) const
{
    double gamma = 1/sqrt(1-A[2]*A[2]);
    double alpha = gamma*A[2]*sqrt(x*x-1)/A[1];
    double beta = gamma*x/A[1];
    double expalpha = exp(alpha);
    double ch = (expalpha + 1/expalpha)/2;
    if(alpha > 30) { // to avoid floating point exceptions
	return 0.5*A[0]*(1+beta-alpha)/alpha*exp(alpha-beta);
    } else {
    	double sh_alpha;
    	if(alpha > 1e-9) {
	    sh_alpha = (expalpha-1/expalpha)/(2*alpha);
    	} else
	    sh_alpha = 1;
    	return A[0]*((1 + beta)*sh_alpha - ch)*exp(-beta);
    }
}

void SiemensRasmussenFF::getDerivatives(double x, int n, double* D, double* Q)
    const
{
    double gamma = 1/sqrt(1-A[2]*A[2]);
    double alpha = gamma*A[2]*sqrt(x*x-1)/A[1];
    double beta = gamma*x/A[1];
    double expalpha = exp(alpha);
    double ch = (expalpha + 1/expalpha)/2;
    double sh_alpha;
    if(alpha > 1e-9) {
	sh_alpha = (expalpha-1/expalpha)/(2*alpha);
    } else
	sh_alpha = 1;
    double xp = exp(-beta);
    double a = (1 + beta)*sh_alpha - ch;
    D[0] = a*xp;
    Q[n*0+0] = 0;
    if(n > 1) {
	double alpha2 = alpha*alpha;
	double dadt = ((1+alpha2)*sh_alpha - (1+beta)*ch)/A[1];
	double daxpdt = dadt*xp + a*xp*beta/A[1];
	D[1] = A[0]*daxpdt;
	Q[n*0+1] = Q[n*1+0] = daxpdt;
	double d2adt2 = (((1+alpha2*beta)*sh_alpha-(1+alpha2-beta)*ch)/A[1]
			 - dadt)/A[1];
	Q[n*1+1] = A[0]*(d2adt2 + beta/A[1]*(2*dadt-2*a/A[1]+a*beta/A[1]))*xp;
	if(n > 2) {
	    double gamma2 = gamma*gamma;
	    double gamma2_v = gamma2/A[2];
	    double v2 = A[2]*A[2];
	    double dbetadv = gamma2*A[2]*beta;
	    double dadv = gamma2_v*((1+beta)*ch -
				    (1+alpha2+(1-v2)*beta)*sh_alpha);
	    double daxpdv = (dadv - a*dbetadv)*xp;
	    D[2] = A[0]*daxpdv;
	    Q[n*0+2] = Q[n*2+0] = daxpdv;
	    double d2advdt = gamma2_v/A[1]*((1+alpha2-v2*beta)*ch
			- (1+alpha2*beta)*sh_alpha);
	    Q[n*1+2] = Q[n*2+1] = A[0]*((d2advdt
					 + gamma2*A[2]*beta*(a/A[1]-dadt))*xp
					+ daxpdv*beta/A[1]);
	    double d2betadv2 = gamma2*beta*(1 + 3*gamma2*A[2]*A[2]);
	    double d2adv2 = (2*gamma2*A[2]-1/A[2])*dadv + gamma2_v*gamma2_v*(
	    	(1+(1-v2)*(1-v2)*beta+alpha2*beta+2*v2*beta/gamma2)*sh_alpha
	      - (1-2*v2*beta+alpha2+beta)*ch);
	    Q[n*2+2] = A[0]*(d2adv2-dbetadv*(2*dadv-a*dbetadv)-a*d2betadv2)*xp;
	}
    }
}
