/*
 * slopefit 1.2, Copyright (C) 1996-2000 Peter Csizmadia
 *
 * This program is protected under the terms of the GNU General Public
 * License (GPL) as published by the Free Software Foundation, Inc.,
 * 675 Mass Ave, Cambridge MA 02139, USA; either version 2 of the
 * License, or (at your option) any later version.
 * http://www.gnu.org/copyleft/gpl.html
 */
#include <math.h>
#include "bessel.h"
#include "K1mtFF.h"

double K1mtFF::eval(double x, const double* A) const
{
    return A[0]*x*besselK1(x/A[1]);
}

void K1mtFF::getDerivatives(double x, int n, double* D, double* Q) const
{
    double K0 = besselK0(x/A[1]);
    double K1 = besselK1(x/A[1]);
    D[0] = x*K1;
    Q[n*0+0] = 0;
    if(n > 1) {
	double xtt = x/(A[1]*A[1]);
	double dadt = K0*xtt + K1/A[1];
	D[1] = A[0]*dadt;
	Q[n*1+0] = Q[n*0+1] = dadt;
	Q[n*1+1] = A[0]*(K1*xtt*xtt - K1*xtt/A[1]);
    }
}
