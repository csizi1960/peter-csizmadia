/*
 * slopefit 1.2, Copyright (C) 1996-2000 Peter Csizmadia
 *
 * This program is protected under the terms of the GNU General Public
 * License (GPL) as published by the Free Software Foundation, Inc.,
 * 675 Mass Ave, Cambridge MA 02139, USA; either version 2 of the
 * License, or (at your option) any later version.
 * http://www.gnu.org/copyleft/gpl.html
 */
#include <math.h>
#include "ExpShFF.h"

double ExpShFF::eval(double x, const double* A) const
{
    double gamma = 1/sqrt(1-A[2]*A[2]);
    double alpha = gamma*A[2]*sqrt(x*x-1)/A[1];
    double sh_alpha;
    if(alpha > 1e-9) {
	sh_alpha = (exp(alpha)-exp(-alpha))/(2*alpha);
    } else
	sh_alpha = 1;
    return A[0]*sh_alpha*x*exp(-gamma*x/A[1]);
}

void ExpShFF::getDerivatives(double x, int n, double* D, double* Q) const
{
    double pt = sqrt(x*x-1);
    double gamma = 1/sqrt(1-A[2]*A[2]);
    double gammavpt = gamma*A[2]*pt;
    double e = gammavpt/A[1];
    double xp = x*exp(-gamma*x/A[1]);
    double exppe = exp(e);
    double expme = exp(-e);
    double sh = (exppe - expme)/2;
    double ch = (exppe + expme)/2;
    D[0] = sh/e*xp;
    Q[n*0+0] = 0;
    if(n > 1) {
    	double dadt = ((1/e+x/(gammavpt))*sh-ch)*xp/A[1];
	double vpt = A[2]*pt;
	double T2 = A[1]*A[1];
    	D[1] = A[0]*dadt;
	Q[n*1+0] = Q[n*0+1] = dadt;
	double c11 = A[0]*gamma/(vpt*T2*A[1]);
	Q[n*1+1] = c11*((vpt*vpt+x*x)*sh - 2*vpt*x*ch)*xp;
	if(n > 2) {
	    double dadv = gamma*gamma/A[2]*(ch-(1/e+A[2]*x/pt)*sh)*xp;
	    D[2] = A[0]*dadv;
	    Q[n*2+0] = Q[n*0+2] = dadv;
	    double T_gamma = A[1]/gamma;
	    double v2 = A[2]*A[2];
	    double c12 = A[0]*gamma*gamma*gamma/(vpt*T2*A[2]);
	    double q12ch = vpt*(x + x*v2 + T_gamma);
	    double q12sh = (2*x*x-1)*v2 + T_gamma*(x + T_gamma);
	    Q[n*2+1] = Q[n*1+2] = c12*(q12ch*ch - q12sh*sh)*xp;
	    double c22 = A[0]*gamma*gamma*gamma*gamma/(vpt*T_gamma*v2);
	    double q22ch = vpt*(T_gamma*(2-3*v2) + 2*v2*x);
	    double q22sh = T2*(2-5*v2+3*v2*v2) + T_gamma*v2*(1-2*v2)*x
			 + v2*(pt*pt+v2*x*x);
	    Q[n*2+2] = c22*(q22sh*sh - q22ch*ch)*xp;
	}
    }
}
