import javax.swing.*;
import java.awt.GridLayout;
import java.awt.event.*;//java11

/**
 * Frame for viewing the coordinates read.
 *
 * Java 1.1 event handling is performed in lines ended with "//java11",
 * old style event handling (for the applet version) is performed in lines
 * ended with "//java10".
 *
 * @version     0.6, 03/17/2004
 * @author      Peter Csizmadia
 */
public class ViewFrame extends JFrame implements WindowListener {

    JTextArea txt;

    public ViewFrame(String s, int rows, int cols) {
	setLayout(new GridLayout(1,1));
	txt = new JTextArea(s, rows, cols);
	txt.setEditable(false);
	addWindowListener(this);//java11
	add(txt);
	pack();
	setVisible(true);//java11
//	show();//java10
    }

   /**
    * Handles the window destroy event.
    */
    public void windowClosing(WindowEvent e) {//java11
	dispose();//java11
//    public boolean handleEvent(Event e) {//java10
//	if(e.id == Event.WINDOW_DESTROY) {//java10
//	    dispose();//java10
//	    return true;//java10
//	} else {//java10
//	    return super.handleEvent(e);//java10
//	}//java10
    }

    public void windowActivated(WindowEvent e) { }//java11
    public void windowClosed(WindowEvent e) { }//java11
    public void windowDeactivated(WindowEvent e) { }//java11
    public void windowDeiconified(WindowEvent e) { }//java11
    public void windowIconified(WindowEvent e) { }//java11
    public void windowOpened(WindowEvent e) { }//java11
};
