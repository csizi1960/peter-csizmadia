import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.datatransfer.*;
import java.io.*;
import java.text.*;
import java.util.Locale;
import java.util.StringTokenizer;

/**
 * Application for reading data points on a figure containing a graph.
 *
 * This class is written using Java 1.1 event handling because it is not
 * used in the applet version.
 *
 * @version     0.6, 03/17/2004
 * @author      Peter Csizmadia
 */
public class Main extends JFrame implements WindowListener {

    private static final String[] IMAGE_FILE_EXTS = new String[] {
	".gif", ".jpg", ".jpeg", ".png"
    };
    private JMenuBar menubar;
    private GRApplet appletpan;
    private JPanel aboutpan;
    private JButton aboutokay;
    private File imgfile = null;
    private File datfile = null;

    private Action loadAction = new AbstractAction() {
	public void actionPerformed(ActionEvent ev) {
	    FileDialog dialog = new FileDialog(Main.this,
					       "Load GIF or datafile",
					       FileDialog.LOAD);
	    String wd = getWd();
	    if(wd != null) {
		dialog.setDirectory(wd);
	    }
	    dialog.setVisible(true);
	    String fname = dialog.getFile();
	    if(fname != null) {
		load(new File(dialog.getDirectory(), fname), false);
	    }
	}
    };

    private Action saveAction = new AbstractAction() {
	public void actionPerformed(ActionEvent ev) {
	    FileDialog dialog = new FileDialog(Main.this, "Save datafile",
					       FileDialog.SAVE);
	    String wd = getWd();
	    if(wd != null) {
		dialog.setDirectory(wd);
	    }
	    String proposedname = getDatafilename();
	    if(proposedname != null) {
		dialog.setFile(proposedname);
	    }
	    dialog.setVisible(true);
	    String fname = dialog.getFile();
	    if(fname != null) {
		fname = new File(fname).getName();
		datfile = new File(dialog.getDirectory(), fname);
		save();
	    }
	}
    };

    private Action exitAction = new AbstractAction() {
	public void actionPerformed(ActionEvent ev) {
	    windowClosing(null);
	}
    };

    private Action copyAction = new AbstractAction() {
	public void actionPerformed(ActionEvent ev) {
	    String s = appletpan.getData(null);
	    Clipboard c = Toolkit.getDefaultToolkit().getSystemClipboard();
	    StringSelection ss = new StringSelection(s);
	    c.setContents(ss, null);
	}
    };

    private Action pasteAction = new AbstractAction() {
	public void actionPerformed(ActionEvent ev) {
	    Clipboard c = Toolkit.getDefaultToolkit().getSystemClipboard();
	    Transferable t = c.getContents(null);

	    // isDataFlavorSupported() is omitted because it causes
	    // java.lang.NullPointerException:
	    // at sun.awt.motif.X11Selection.isDataFlavorSupported(X11Selection.java:215)
	    // in the linux ports of jdk (and maybe elsewhere also)
	    if(t != null) { // && t.isDataFlavorSupported(DataFlavor.stringFlavor)) {
		try {
		    String s = (String)t.getTransferData(DataFlavor.stringFlavor);
		    readData(s, null);
		} catch(Exception exc) {
		    exc.printStackTrace();
		}
	    }
	}
    };

    private Action aboutAction = new AbstractAction() {
	public void actionPerformed(ActionEvent ev) {
	    remove(appletpan);
	    getContentPane().add("Center", aboutpan);
	    aboutAction.setEnabled(false);
	    validate();
	}
    };

    private Action aboutOkayAction = new AbstractAction() {
	public void actionPerformed(ActionEvent ev) {
	    closeAbout();
	}
    };

    private Action demoAction = new AbstractAction() {
	public void actionPerformed(ActionEvent ev) {
	    closeAbout();
	    load(new File(System.getProperty("demofile")), false);
	}
    };

    public Main(File file) {
	loadAction.putValue(Action.NAME, "Open");
	loadAction.putValue(Action.SHORT_DESCRIPTION, "Load GIF or datafile");
	loadAction.putValue(Action.MNEMONIC_KEY, new Integer('o'));
	loadAction.putValue(Action.ACCELERATOR_KEY,
		getCommandKeyStroke(KeyEvent.VK_O));
	saveAction.putValue(Action.NAME, "Save As...");
	saveAction.putValue(Action.SHORT_DESCRIPTION, "Save datafile");
	saveAction.putValue(Action.MNEMONIC_KEY, new Integer('a'));
	saveAction.putValue(Action.ACCELERATOR_KEY,
		getCommandKeyStroke(KeyEvent.VK_S));
	exitAction.putValue(Action.NAME, "Exit");
	exitAction.putValue(Action.SHORT_DESCRIPTION, "Exit");
	exitAction.putValue(Action.MNEMONIC_KEY, new Integer('x'));
	exitAction.putValue(Action.ACCELERATOR_KEY,
		getCommandKeyStroke(KeyEvent.VK_Q));
	copyAction.putValue(Action.NAME, "Copy");
	copyAction.putValue(Action.SHORT_DESCRIPTION, "Copy");
	copyAction.putValue(Action.MNEMONIC_KEY, new Integer('c'));
	copyAction.putValue(Action.ACCELERATOR_KEY,
		getCommandKeyStroke(KeyEvent.VK_C));
	pasteAction.putValue(Action.NAME, "Paste");
	pasteAction.putValue(Action.SHORT_DESCRIPTION, "Paste");
	pasteAction.putValue(Action.MNEMONIC_KEY, new Integer('p'));
	pasteAction.putValue(Action.ACCELERATOR_KEY,
		getCommandKeyStroke(KeyEvent.VK_V));
	aboutAction.putValue(Action.NAME, "About Graph Redigitizer");
	aboutAction.putValue(Action.MNEMONIC_KEY, new Integer('a'));
	aboutOkayAction.putValue(Action.NAME, "OK");
	demoAction.putValue(Action.NAME, "Demo");
	demoAction.putValue(Action.MNEMONIC_KEY, new Integer('d'));

	if(file != null && !file.isAbsolute()) {
	    file = new File(getWd(), file.getPath());
	}
	setTitle("Graph Redigitizer");
	setJMenuBar(menubar = new JMenuBar());
	JMenu filemenu = new JMenu("File");
	filemenu.setMnemonic('f');
	filemenu.getPopupMenu().setLightWeightPopupEnabled(false);
	JMenu editmenu = new JMenu("Edit");
	editmenu.setMnemonic('e');
	editmenu.getPopupMenu().setLightWeightPopupEnabled(false);
	JMenu helpmenu = new JMenu("Help");
	helpmenu.setMnemonic('h');
	helpmenu.getPopupMenu().setLightWeightPopupEnabled(false);
	menubar.add(filemenu);
	menubar.add(editmenu);
	menubar.add(helpmenu);
	JMenuItem mi;
	filemenu.add(mi = new JMenuItem(loadAction));
	filemenu.add(new JMenuItem(saveAction));
	filemenu.add(new JMenuItem(exitAction));
	editmenu.add(new JMenuItem(copyAction));
	editmenu.add(new JMenuItem(pasteAction));
	helpmenu.add(new JMenuItem(aboutAction));
	helpmenu.add(new JMenuItem(demoAction));
	if(System.getProperty("demofile") == null) {
	    demoAction.setEnabled(false);
	}
	saveAction.setEnabled(false);
	Container contentPane = getContentPane();
	contentPane.setLayout(new BorderLayout());
	appletpan = new GRApplet();
//	appletpan.params = "logx=0&logy=1&sort=1&x0=0&y0=0&x1=1&y1=1&p1=348&q1=393&p2=56&q2=46";
	appletpan.params = "logx=0&logy=0&sort=1";
	appletpan.init();
	if(file != null) {
	    load(file, true);
	}
	appletpan.start();
	contentPane.add("Center", appletpan);
	aboutpan = new JPanel();
	GridBagLayout gbl = new GridBagLayout();
	GridBagConstraints gbc = new GridBagConstraints();
	aboutpan.setLayout(gbl);
	TextArea t = new TextArea(appletpan.getAppletInfo());
	t.setEditable(false);
	JButton aboutokay = new JButton(aboutOkayAction);
	gbc.gridx = 0;
	gbc.gridy = 0;
	gbc.weightx = 1.0;
	gbc.weighty = 1.0;
	gbc.fill = GridBagConstraints.BOTH;
	gbc.anchor = GridBagConstraints.CENTER;
	aboutpan.add(t);
	gbl.setConstraints(t, gbc);
	gbc.gridy = 1;
	gbc.weighty = 0;
	gbc.fill = GridBagConstraints.NONE;
	aboutpan.add(aboutokay);
	gbl.setConstraints(aboutokay, gbc);

	addWindowListener(this);
    }

   /**
    * Handles window destroy event.
    */
    public void windowClosing(WindowEvent e) {
	dispose();
	appletpan.stop();
	System.exit(0);
    }

    public void windowActivated(WindowEvent e) { }
    public void windowClosed(WindowEvent e) { }
    public void windowDeactivated(WindowEvent e) { }
    public void windowDeiconified(WindowEvent e) { }
    public void windowIconified(WindowEvent e) { }
    public void windowOpened(WindowEvent e) { }

    /**
     * Alert.
     */
    private void closeAbout() {
	Container contentPane = getContentPane();
	if(contentPane.getComponent(0) == aboutpan) {
	    contentPane.remove(aboutpan);
	    contentPane.add("Center", appletpan);
	    aboutAction.setEnabled(true);
	    validate();
	}
    }

    /**
     * Alert.
     */
    private void alert(String s) {
	System.out.println(s);
    }

    /**
     * Save data file.
     */
    private void save() {
	if(datfile == null) {
	    if(imgfile != null) {
		datfile = new File(getDatafilename());
	    } else {
		return;
	    }
	}
	setTitle("Grdig: ".concat(datfile.getName()));
	try {
	    String imgname = imgfile.getName();
	    File f1 = new File(imgfile.getCanonicalPath());
	    File f2 = new File(datfile.getCanonicalPath());
	    if(!f1.getParent().equals(f2.getParent())) {
		imgname = imgfile.getAbsolutePath();
	    }
	    FileOutputStream fos = new FileOutputStream(datfile.getAbsolutePath());
	    DataOutputStream dos = new DataOutputStream(fos);
	    dos.writeBytes(appletpan.getData(imgname));
	    dos.close();
	    fos.close();
	} catch(Throwable exc) {
	    exc.printStackTrace();
	}
    }

    /**
     * Load a file.
     */
    private void load(File file, boolean wait) {
	String fname = file.getAbsolutePath();
	setTitle("Grdig: ".concat(fname));
	String s = fname.toLowerCase();
	if(isImageFile(s)) {
	    imgfile = file;
	    datfile = null;
	    appletpan.loadImage(file.getAbsolutePath(), wait);
	} else {
	    loadData(file);
	}
	saveAction.setEnabled(true);
    }

    private boolean isImageFile(String f) {
	for(int i = 0; i < IMAGE_FILE_EXTS.length; ++i) {
	    if(f.endsWith(IMAGE_FILE_EXTS[i])) {
		return true;
	    }
	}
	return false;
    }

    /**
     * Load data file.
     */
    private void loadData(File file) {
	if(file == null) {
	    return;
	}
	try {
	    FileReader fr = new FileReader(file.getAbsolutePath());
	    BufferedReader br = new BufferedReader(fr);
	    String s;
	    StringBuffer sbuf = new StringBuffer();
	    while((s = br.readLine()) != null) {
		sbuf.append(s);
		sbuf.append('\n');
	    }
	    readData(sbuf.toString(), file);
	} catch(Throwable exc) {
	    exc.printStackTrace();
	}
    }

    /**
     * Read data from a string.
     */
    private void readData(String data, File file) {
	if(!data.startsWith("# img=") && file != null) {
	    alert("This is not a grdig datafile");
	}
	try {
	    String s;
	    BufferedReader br = new BufferedReader(new StringReader(data));
	    for(int l=0; (s = br.readLine()) != null; ++l) {
		if(l == 0 && s.startsWith("# img=")) {
		    appletpan.params = s.substring(2);
		    appletpan.reset();
		    if((s = appletpan.getParameter("img")) == null) {
			alert("No image file");
		    } else {
		        imgfile = new File(s);
		    }
		    if(file != null && !imgfile.isAbsolute()) {
			imgfile = new File(file.getParent(), imgfile.getPath());
		    }
		    setTitle("Grdig: ".concat((file != null)? file.getName()
						    : imgfile.getName()));
		    appletpan.loadImage(imgfile.getAbsolutePath(), false);
		} else if(s.length() > 0) {
		    s = s.trim();
		    StringTokenizer st = new StringTokenizer(s, " \t");
		    String[] cols = new String[st.countTokens()];
		    for(int i = 0; i < cols.length; ++i) {
			cols[i] = st.nextToken();
		    }
		    if(cols[0].startsWith("#")) {
			continue;
		    }
		    double x = Double.valueOf(cols[0]).doubleValue();
		    double y = Double.valueOf(cols[1]).doubleValue();
		    double z = cols.length > 2?
			Double.valueOf(cols[2]).doubleValue() : 0;
		    double[] U = appletpan.transform(x, y, z, true);
		    appletpan.setp(U[0], U[1], U[2], -1);
		    U = appletpan.transform(U[0], U[1], U[2], false);
		}
	    }
	    saveAction.setEnabled(true);
	    datfile = file;
	} catch(Throwable exc) {
	    exc.printStackTrace();
	}
    }

    /**
     * Guess the working directory.
     */
    private String getWd() {
	if(datfile != null && datfile.isAbsolute()) {
	    return datfile.getParent();
	} else if(imgfile != null && imgfile.isAbsolute()) {
	    return imgfile.getParent();
	} else {
	    return System.getProperty("user.dir");
	}
    }

    /**
     * Propose a name for the data file.
     */
    private String getDatafilename() {
	if(datfile != null) {
	    return datfile.getAbsolutePath();
	} else if(imgfile != null) {
	    String s = imgfile.getAbsolutePath();
	    String sl = s.toLowerCase();
	    String base;
	    if(isImageFile(sl)) {
		int doti = sl.lastIndexOf('.');
		base = s.substring(0, doti);
	    } else {
		base = s;
	    }
	    return base.concat(".data");
	}
	return null;
    }

    private static KeyStroke getCommandKeyStroke(int key) {
	return KeyStroke.getKeyStroke(key,
		Toolkit.getDefaultToolkit().getMenuShortcutKeyMask());
    }

    public static void main(String args[]) {
	File file = null;
	for(int i=0; i<args.length; ++i) {
	    String s = args[i];
	    String sl = s.toLowerCase();
	    if(s.startsWith("-")) {
		System.out.println("usage: grdig file");
		System.out.println("file must be an image (GIF or JPEG) or a grdig datafile");
		System.exit(0);
	    } else {
		file = new File(s);
	    }
	}
	Main f = new Main(file);
	f.pack();
	f.setVisible(true);
    }
}
