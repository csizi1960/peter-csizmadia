import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;

/**
 * The canvas containing the figure with the graph.
 *
 * @version     0.6, 03/17/2004
 * @author      Peter Csizmadia
 */
class ImgCanvas extends JComponent implements MouseMotionListener {

    /** The image. */
    Image image;

    /** The points. */
    Vector points;

    /** Image for double buffering. */
    Image backimg;

    /**
     * Canvas type.
     * @see #CENTRAL
     * @see #HORIZONTAL
     * @see #VERTICAL
     */
    int type;

    /**
     * Smart scrolling mode.
     */
    boolean smartmode = false;

    /**
     * Magnification.
     */
    double magn = 1.0;

    /** Central point x. */
    double xcenter = 0.0;

    /** Central point y. */
    double ycenter = 0.0;

    /** Central canvas. */
    public static final int CENTRAL = 0;

    /** Horizontal canvas (x axis). */
    public static final int HORIZONTAL = 1;

    /** Vertical canvas (y axis). */
    public static final int VERTICAL = 2;

    /** Mouse location */
    private Point mouloc = new Point(0,0);

    /** Critical radius */
    private int radius = 0;

    /**
     * Create an image canvas.
     * @see #CENTRAL
     * @see #HORIZONTAL
     * @see #VERTICAL
     */
    public ImgCanvas(int type) {
	this.type = type;
	addMouseMotionListener(this);
    }

    /**
     * Set the image.
     */
    public void setImage(Image img) {
	this.image = img;
    }

    /**
     * Set the data point vector.
     */
    public void setPoints(Vector points) {
	this.points = points;
    }

    /**
     * Set the central point and the magnification.
     */
    public void setPos(double x, double y, double m) {
	xcenter = x;
	ycenter = y;
	magn = m;
	repaint();
    }

    /**
     * Set smart scrolling mode.
     */
    public void setSmartmode(boolean m) {
	smartmode = m;
	repaint();
    }

    /**
     * Get mouse location.
     */
    public Point getMouseLoc() {
	return mouloc;
    }

    /**
     * Get critical radius.
     */
    public int getRadius() {
	return radius;
    }

    /**
     * Paint the image.
     */
    public void paint(Graphics g) {
	update(g);
    }

    /**
     * Paint the image.
     */
    public void update(Graphics fg) {
	Dimension sz = getSize();
	int szw = sz.width;
	int szh = sz.height;
	int iw = 0;
	int ih = 0;
	if(image != null) {
	    iw = image.getWidth(this);
	    ih = image.getHeight(this);
	}
	if(szw <= 0 || szh <= 0) {
	    return;
	}
	radius = ((szw > szh)? szh : szw)/3;
	if(backimg == null || 
	   szw != backimg.getWidth(null) || szh != backimg.getHeight(null)) {
	    backimg = createImage(szw, szh);
	}
	if(iw <= 0 || ih <= 0) {
	    return;
	}
	int xc = szw/2;
	int yc = szh/2;
	int x0 = (int) Math.round(xc - xcenter*magn);
	int y0 = (int) Math.round(yc - ycenter*magn);
	int w = (int) (iw*magn + 0.5);
	int h = (int) (ih*magn + 0.5);
	Graphics g = backimg.getGraphics();
	g.setColor(getBackground());
	g.fillRect(0, 0, szw, szh);
	if(image != null) {
	    g.drawImage(image, x0, y0, w, h, this);
	}
	g.setColor(Color.blue);
	if(type == CENTRAL) {
	    if(smartmode) {
		g.drawRect(xc-radius, yc-radius, 2*radius, 2*radius);
	    }
	    g.drawLine(xc-radius*3/4, yc, xc-radius*9/8, yc);
	    g.drawLine(xc+radius*3/4, yc, xc+radius*9/8, yc);
	    g.drawLine(xc, yc-radius*3/4, xc, yc-radius*9/8);
	    g.drawLine(xc, yc+radius*3/4, xc, yc+radius*9/8);
	    g.drawLine(xc, yc-radius/4, xc, yc+radius/4);
	    g.drawLine(xc-radius/4, yc, xc+radius/4, yc);
	} else if(type == HORIZONTAL) {
	    g.drawLine(xc, yc-radius, xc, yc+radius);
	} else if(type == VERTICAL) {
	    g.drawLine(xc-radius, yc, xc+radius, yc);
	}
	Enumeration e = points.elements();
	for(int i=-2; e.hasMoreElements(); ++i) {
	    double xx = ((Double)e.nextElement()).doubleValue();
	    double yy = ((Double)e.nextElement()).doubleValue();
	    double dyy = 0;
	    if(i > 0) {
		dyy = ((Double)e.nextElement()).doubleValue();
	    }
	    int x = type == VERTICAL? xc : (int) Math.round(x0 + xx*magn);
	    int y = type == HORIZONTAL? yc : (int) Math.round(y0 + yy*magn);
	    int ye = type == HORIZONTAL? yc
				       : (int) Math.round(y0 + (yy+dyy)*magn);
	    if(type != HORIZONTAL) {
		g.drawLine(x-radius/8, y, x+radius/8, y);
		g.drawLine(x-radius/16, ye, x+radius/16, ye);
	    }
	    if(type != VERTICAL) {
		g.drawLine(x, y+radius/8, x, y-radius/8);
		g.drawLine(x, ye+radius/16, x, ye-radius/16);
	    }
	    FontMetrics fm = getFontMetrics(getFont());
	    String s;
	    switch(i) {
		case -2: s = "calO"; break;
		case -1: s = "calX"; break;
		case 0: s = "calY"; break;
		default: s = String.valueOf(i);
	    }
	    if(type != CENTRAL && i<1) {
		s = "";
	    }
	    int sw = fm.stringWidth(s);
	    if(type == CENTRAL) {
		y -= fm.getDescent() + radius/8;
	    } else if(type == HORIZONTAL) {
		y += fm.getAscent() + radius/8;
	    } else if(type == VERTICAL) {
		y += (fm.getAscent()-fm.getDescent())/2;
		x -= sw/2 + radius/8;
	    }
	    g.drawString(s, x-sw/2, y);
	}
	fg.drawImage(backimg, 0, 0, null);
	g.dispose();
    }

   /** Get the preferred size. */
    public synchronized Dimension getPreferredSize() {
	if(image != null && type == CENTRAL) {
	    int w = image.getWidth(null);
	    int h = image.getHeight(null);
	    if(w > 0 && h > 0) {
		Toolkit tk = Toolkit.getDefaultToolkit();
		if(tk != null) {
		    Dimension scrsize = tk.getScreenSize();
		    int wm = scrsize.width/2;
		    int hm = scrsize.height/2;
		    if(wm > 0 && w > wm) {
			w = wm;
		    }
		    if(hm > 0 && h > hm) {
			h = hm;
		    }
		}
		return new Dimension(w, h);
	    }
	}
	return super.getPreferredSize();
    }

    public void mouseMoved(MouseEvent e) {
	mouloc = new Point(e.getX(), e.getY());
    }

    public void mouseDragged(MouseEvent e) {
	mouloc = new Point(e.getX(), e.getY());
    }

    public boolean imageUpdate(Image img, int flags,
			       int x, int y, int w, int h)
    {
	if((flags & (FRAMEBITS|ALLBITS)) != 0) {
	    repaint();
	} else if((flags & SOMEBITS) != 0) {
	    repaint(200, x, y, w, h);
	}
	return (flags & (ALLBITS|ABORT)) == 0;
    }
};
