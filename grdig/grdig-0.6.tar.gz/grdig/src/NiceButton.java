import javax.swing.*;
import java.awt.*;
import java.awt.event.*;//java11
import java.util.Random;

/**
 * Button with label and/or icon.
 * The down and the up state have their own description strings.
 *
 * Java 1.1 event handling is performed in lines ended with "//java11",
 * old style event handling (for the applet version) is performed in lines
 * ended with "//java10".
 *
 * @version	0.6, 03/17/2004
 * @author	Peter Csizmadia
 */
public final class NiceButton extends JButton implements MouseListener {

   /** Label style. */
    public final static int LABEL = 1;

   /** Hidden 3D style. */
    public final static int HIDDEN3D = 2;

   /** Button state: down. */
    public final static int DOWN = 1;

   /** Button state: mouse is over the button. */
    public final static int MOUSEOVER = 2;

   /** Button state: disabled (grayed out). */
    public final static int DISABLED = 4;

   /** Random number generator for cross creation. */
    private static Random rnd = new Random();

   /** The requested size of the component */
    private Dimension reqsize = null;

   /** Button style. */
    private int style = 0;

    // common privates
    private String descriptions[];
    private int state = 0;
    private int prevstate = -1;
    private boolean wasdown;
    // mouse state
    private boolean dragged;
    private boolean msdown; // mouse button is down

   /** Cross coordinates for "real" checkbox. */
    private int crossX[] = new int[8];

   /** Cross calculation request. */
    private boolean crossreq = false;

   /** Checkbox size. */
    public int cbsize = 0;

   /** Button label. */
    private String label;

   /** y distance of the top of label from the origin. */
    private int labelascent;

   /** Minimum width of label in pixels. */
    private int labelwidth;

   /** Minimum height of label in pixels. */
    private int labelheight;

   /** True if the button has label. */
    private boolean haslabel;

    // icon
    private Image[] icons = new Image[8];
    private int[] iconleft = new int[4]; // smallest x of icon
    private int[] icontop = new int[4]; // smallest y of icon
    private int iconwidth, iconheight; // size of icon in pixels

   /**
    * The button's distance from its shadow.<br>
    * Default value: 6.
    */
    public int depth = 2;

   /**
    * Create a button.
    */
    public NiceButton(Action action) {
	super(action);
	setLabel((String)action.getValue(Action.NAME));
	descriptions = null;
	addMouseListener(this);
    }

   /**
    * Create a button.
    * @param l	the label
    * @param d	description array
    */
    public NiceButton(String l, String[] d) {
	this(l);
	descriptions = d;
    }

   /**
    * Create a button.
    * @param l	the label
    * @param d	description
    */
    public NiceButton(String l, String d) {
	this(l);
	descriptions = new String[2];
	descriptions[0] = d;
    }

   /** Set the font of the label. */
    public void setFont(Font f) {
	super.setFont(f);
	geom();
    }

   /**
    * Set the button style.
    * @see #LABEL
    * @see #HIDDEN3D
    */
    public void setStyle(int s) {
	style = s;
    }

   /**
    * Set the button depth.<br>
    * The default depth is 2 pixels.
    */
    public void setDepth(int d) {
	depth = d;
    }

   /**
    * Does it have an icon?
    */
    public boolean hasIcon() {
	return icons[0] != null;
    }

   /**
    * Query the button's state.
    * @return true if down, false if up
    */
    public boolean getState() {
	return (state & DOWN) != 0;
    }

   /**
    * Set the button's state.
    * Only meaningful for checkable buttons.
    * @param v new state
    */
    public synchronized void setState(boolean v) {
	if(descriptions[1] == null ||
	   ((state & DOWN) != 0) == v)
	    return;
	if(v) {
	    state |= DOWN;
	    mkCross();
	} else
	    state &= ~DOWN;
	if(state != prevstate)
	    repaint1();
    }

   /** Enable or disable (gray out) the button. */
    public synchronized void setEnabled(boolean e) {
	int s = state;
	if(e)
	    state &= ~DISABLED;
	else
	    state |= DISABLED;
	if(state != prevstate)
	    repaint1();
	super.setEnabled(e);//java11
//	super.enable(e);//java10
    }

   /**
    * Change the label for a mouse state.
    */
    public void setLabel(String l) {
	if(l != null && l.length() == 0)
	    l = null;
	if((label != null && l != null && !label.equals(l)) ||
	   (label != null && l == null) || (label == null && l != null)) {
	    label = l;
	    haslabel = l != null;
	    repaint();
	}
    }

   /** Query the description string. */
    public synchronized String getDescription() {
	String altdesc = descriptions[1];
	return ((state & DOWN)==0 || altdesc==null)?
		descriptions[0] : descriptions[1];
    }

   /** Get the minimum size required to display the label. */
    public synchronized Dimension getMinimumSize() {//java11
//    public synchronized Dimension minimumSize() {//java10
	int d = 2*depth;
	int w1 = 0;
	int h1 = 0;
	geom();
	if(haslabel) {
	    w1 = labelwidth;
	    h1 = labelheight;
	} else if(descriptions[1] != null && !hasIcon()) { // "real" checkbox
	    w1 = h1 = d + cbsize;
	}
	int w2 = 0;
	int h2 = 0;
	if(icons[0] != null) {
	    w2 = icons[0].getWidth(null);
	    h2 = icons[0].getHeight(null);
	}
	return (reqsize != null)?
		reqsize : new Dimension(((w1>w2)? w1 : w2) + d, h1 + h2 + d);
    }

   /** Set the requested size of the button. */
    public synchronized void setReqSize(Dimension d) {
	reqsize = d;
    }

   /**
    * Set the background images corresponding to the button states.<br>
    * If the icon for a button state is <code>null</code>, it defaults to
    * <code>icons[0]</code>.
    */
    public void setIcons(Image[] icons) {
	for(int i=0; i<icons.length; ++i) {
	    this.icons[i] = (i == 0 || icons[i] != null)? icons[i] : icons[0];
	}
	for(int i=icons.length; i<8; ++i) {
	    this.icons[i] = this.icons[DISABLED];
	}
    }

   /**
    * Get the preferred size.
    * @return the requested size (if there is) or the minimum size
    * @see #minimumSize
    * @see #setReqSize
    */
    public synchronized Dimension getPreferredSize() {//java11
	return (reqsize != null)? reqsize : getMinimumSize();//java11
//    public synchronized Dimension preferredSize() {//java10
//	return (reqsize != null)? reqsize : minimumSize();//java10
    }

   /** Does the same as <a href="#update">update</a>. */
    public void paint(Graphics g) {
	update(g);
    }

   /** Paints the component. */
    public void update(Graphics gg) {
	Dimension dim = getSize();//java11
//	Dimension dim = size();//java10
	int width = dim.width;
	int height = dim.height;
	int w = width - (depth<<1);
	int h = height - (depth<<1);
	boolean hasicon = hasIcon();

	// "real" checkbox
	boolean realcb = descriptions[1] != null && !hasicon && !haslabel;

	if(w <= 0 || h <= 0)
	    return;
	geom();
	int i = state;
	boolean enabled = (i & DISABLED) == 0;
	Color surfcolor = getBackground();
	if((style & LABEL) == 0 && !realcb) {
	    if(i == DOWN)
		surfcolor = brighter(surfcolor, 0.83);
	    else if((style & HIDDEN3D) == 0 && i == MOUSEOVER)
		surfcolor = brighter(surfcolor, 1.2);
	}
	Color darkerthanbg = surfcolor.darker();
	Image im = createImage(width, height);
	Graphics g = im.getGraphics();
	g.setFont(getFont());
	g.setColor(surfcolor);
	drawSurf(g, width, height);
	// label
	i &= 3;
	iconleft[i] = icontop[i] = depth;
	iconwidth = w;
	iconheight = h;
	Dimension iconsize = new Dimension(w, h);
	if(haslabel) {
	    g.setColor(enabled? Color.black : darkerthanbg);
	    int y = depth + labelascent;
	    if(!hasicon)
		y += (h - labelheight)/2;
	    g.drawString(label, depth + (iconwidth-labelwidth)/2, y);
	    // the icon's drawing area will be below the label
	    icontop[i] += labelheight;
	    iconheight -= labelheight;
	}
	if(realcb) {
	    g.setColor(enabled? Color.black : darkerthanbg);
	    g.drawRect(depth<<1, depth<<1, cbsize-1, cbsize-1);
	    if((i & DOWN) != 0) {
		if(enabled)
		    g.setColor(Color.blue);
		g.drawLine(crossX[0], crossX[1], crossX[4], crossX[5]);
		g.drawLine(crossX[6], crossX[2], crossX[3], crossX[7]);
	    }
	}
	// icon
	if(hasicon) {
	    g.translate(iconleft[i], icontop[i]);
	    g.clipRect(0, 0, iconwidth, iconheight);
	    if(icons[state] != null) {
		Image img = icons[state];
		int wi = img.getWidth(null);
		int hi = img.getHeight(null);
		g.drawImage(img, (iconwidth-wi)/2, (iconheight-hi)/2, null);
	    }
	}
	gg.drawImage(im, 0, 0, null);
	im.flush();
	g.dispose();
    }

   /** Draw the surface of the button. */
    void drawSurf(Graphics g, int width, int height) {
	int s = state;
	boolean h3d = (style & HIDDEN3D) != 0;
	boolean up = (s & DOWN) == 0;
	boolean mo = (s & MOUSEOVER) != 0;

	// "real" checkbox
	boolean realcb = descriptions[1] != null && !hasIcon() && !haslabel;

	if((style & LABEL) == 0 && (s & DISABLED) == 0 &&
	   (!h3d || !up || mo) &&
	   (!realcb || (!msdown && mo))) {
	    g.fillRect(depth, depth, width-(depth<<1), height-(depth<<1));
	    for(int x=depth; x>0; --x) {
		int w = width - (x<<1);
		int h = height - (x<<1);
		g.draw3DRect(x, x, w, h, realcb || up);
	    }
	} else {
	    g.fillRect(0, 0, width, height);
	}
    }

   /** Mouse entered. */
    public void mouseEntered(MouseEvent e) {//java11
//    public boolean mouseEnter(Event e, int x, int y) {//java10
	if((state & DISABLED) != 0)
	    return;//java11
//	    return true;//java10
	state |= MOUSEOVER;
	repaint1();
//	return false;//java10
    }

   /** Mouse exited. */
    public void mouseExited(MouseEvent e) {//java11
//    public boolean mouseExit(Event e, int x, int y) {//java10
	state &= ~MOUSEOVER;
	repaint1();
//	return false;//java10
    }

   /** Mouse button pressed. */
    public void mousePressed(MouseEvent e) {//java11
//    public boolean mouseDown(Event e, int x, int y) {//java10
	msdown = true;
	if((state & DISABLED) != 0)
	    return;//java11
//	    return true;//java10
	wasdown = (state & DOWN) != 0;
	state |= DOWN;
	if(!wasdown)
	    mkCross();
	repaint1();
//	return false;//java10
    }

   /** Mouse button released. */
    public void mouseReleased(MouseEvent e) {//java11
//    public boolean mouseUp(Event e, int x, int y) {//java10
	msdown = false;
	if(!(descriptions[1] != null && dragged) &&
	   (descriptions[1] == null || wasdown)) {
	    state &= ~DOWN;
	}
	dragged = false;
	repaint1();
//	return false;//java10
    }

    public void mouseClicked(MouseEvent e) { }//java11

   /**
    * Private button constructor called by all the public ones.
    * @param l	the label
    */
    private NiceButton(String l) {
	super();
	setLabel(l);
	descriptions = null;
	addMouseListener(this);//java11
    }

   /** Repaint and memorize state. */
    private void repaint1() {
	repaint();
	prevstate = state;
    }

   /** Calculate the label geometry. */
    private void geom() {
	FontMetrics fm = getFontMetrics(getFont());
	int asc = fm.getAscent();
	int h = asc + fm.getDescent() + 1;
	if(label != null) {
	    labelascent = asc;
	    labelwidth = fm.stringWidth(label);
	    labelheight = h;
	}
	cbsize = h - (depth<<1);
	if(crossreq)
	    mkCross();
    }

   /**
    * Make cross for the "real" checkbox.
    */
    private void mkCross() {
	if(cbsize == 0) {
	    crossreq = true;
	} else {
	    int d = depth;
	    int l = d + cbsize;
	    for(int i=0; i<8; ++i) {
		crossX[i] = d + rnd.nextInt()%d;
		if(i >= 4)
		    crossX[i] += l;
	    }
	    crossreq = false;
	}
    }

   /**
    * Make a brighter or darker color than the specified one.
    * @param c	the color
    * @param f	the relative brightness
    */
    private static Color brighter(Color c, double f) {
	return new Color(Math.min((int)(c.getRed()*f), 255),
			 Math.min((int)(c.getGreen()*f), 255),
			 Math.min((int)(c.getBlue()*f), 255));
    }
}
