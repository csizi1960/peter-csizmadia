import javax.swing.*;
import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Frame;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import java.awt.Image;
import java.awt.MediaTracker;
import java.awt.Point;
import java.awt.Toolkit;
import java.awt.event.*;
import java.awt.image.MemoryImageSource;
import java.net.*;
import java.util.Vector;

/**
 * Applet for reading data points on a figure containing a graph.
 *
 * @version     0.6, 03/17/2004
 * @author      Peter Csizmadia
 */
public class GRApplet extends javax.swing.JApplet implements Runnable
,		MouseListener, KeyListener, AdjustmentListener
{
    /**
     * The parameters.
     * Used if this component is a panel in the frame of an application.
     */
    public String params = null;

    /** The image. */
    private Image image = null;

    /** The image filename. */
    private String imgname = null;

    /** Horizontal scrollbar. */
    private JScrollBar xscrbar;

    /** Vertical scrollbar. */
    private JScrollBar yscrbar;

    /** Panel containing an Erase button and numbered buttons for each point. */
    private JPanel ptpan;

    /** Central image canvas. */
    private ImgCanvas imgcanc;

    /** Horizontal image canvas (x axis). */
    private ImgCanvas imgcanx;

    /** Vertical image canvas (y axis). */
    private ImgCanvas imgcany;

    /** Magnification buttons. */
    private NiceButton[] magbtn = new NiceButton[3];

    /** Erase button. */
    private NiceButton erasebtn;

    /** Show button. */
    private NiceButton showbtn;

    /** The main thread. */
    private Thread thread;

    /** The current time. */
    private long time;

    /** Mouse button is down. */
    private boolean mdown = false;

    /** Time of the button press. */
    private long mdownwhen;

    /** Image width known. */
    private boolean widthknown = false;

    /** Image height known. */
    private boolean heightknown = false;

    /** Image height known. */
    private boolean centralized = false;

    /** Logscale X and Y checkboxes. */
    private NiceButton logscb[] = new NiceButton[2];

    /** Calibration buttons. */
    private NiceButton calbtn[] = new NiceButton[3];

    /** Calibration point textfields. */
    private JTextField caltxt[] = new JTextField[6];

    /** Autosort checkbox. */
    private NiceButton sortcb;

    /**
     * Text field containing the current coordinates.<br>
     * We must use NiceButton because AWT TextField and Label are not
     * double buffering.
     */
    private NiceButton crdtxt;

    /** Magnification. */
    private double magn = 1.0;

    private double xcenter = 0;
    private double ycenter = 0;
    private double xcenter0 = 0;
    private double ycenter0 = 0;

    private Vector points = new Vector();

    /** Current point index. */
    private int currentIndex = -1;

    private static final Font btnfnt = new Font("TimesRoman", Font.BOLD, 12);
    private static final Font fixfnt = new Font("Courier", Font.PLAIN, 12);

    private Action markAction = new AbstractAction() {
	public void actionPerformed(ActionEvent ev) {
	    setp();
	}
    };

    private Action markErrorAction = new AbstractAction() {
	public void actionPerformed(ActionEvent ev) {
	    int k = -1;
	    double dxmin = Double.MAX_VALUE;
	    for(int i = 6; i < points.size(); i += 3) {
		double x = ((Double)points.elementAt(i)).doubleValue();
		double dx = Math.abs(x - xcenter);
		if(dx < dxmin) {
		    dxmin = dx;
		    k = i;
		}
	    }
	    if(k >= 0) {
		double y = ((Double)points.elementAt(k + 1)).doubleValue();
		double dy = y - ycenter;
		points.setElementAt(new Double(dy), k + 2);
	    }
	}
    };

    static boolean scrollbug;

    static {
	String vendor = System.getProperty("java.vendor");
	String ver = System.getProperty("java.version");
	scrollbug = (vendor.equals("Microsoft Corp.")
			&& (ver.startsWith("1.0") || ver.equals("1.1")))
		    || (vendor.equals("Netscape Communications Corporation")
			&& (ver.startsWith("1.0") || ver.equals("1.1.2")));
    }

    public GRApplet() {
	markAction.putValue(Action.NAME, "Mark");
	markAction.putValue(Action.SHORT_DESCRIPTION, "Mark data point");
	markErrorAction.putValue(Action.NAME, "Errorbar");
	markErrorAction.putValue(Action.SHORT_DESCRIPTION,
				 "Mark end of errorbar");
    }

   /**
    * Returns a string containing the version and the author.
    */
    public String getAppletInfo() {
	return "Graph ReDIGitizer 0.6 (http://www.kfki.hu/~cspeter/grdig/)\n"+
	       "Copyright (C) 1998-2004 Peter Csizmadia\n\n"+
	"A graphics tool for reading the coordinates of data points from\n"+
	"linear and logscaled graphs. The input is a GIF file, the output\n"+
	"is a two-column table containing the coordinates of the points\n"+
	"marked by you.\n\n"+
	"Written in Java.\n\n"+
	"This program is protected under the terms of the GNU General Public\n"+
	"License (GPL) as published by the Free Software Foundation, Inc.,\n"+
	"675 Mass Ave, Cambridge MA 02139, USA; either version 2 of the\n"+
	"License, or (at your option) any later version.\n"+
	"http://www.gnu.org/copyleft/gpl.html\n";
    }

   /**
    * Get a parameter.
    */
    public String getParameter(String s) {
	if(params == null)
	    return super.getParameter(s);
	else {
	    int i = -1;
	    s = s.concat("=");
	    if(params.startsWith(s)) {
		i = s.length();
	    } else if((i = params.indexOf("&".concat(s))) != -1) {
		i += s.length()+1;
	    }
	    if(i == -1 || params.length() <= i) {
		return null;
	    }
	    int j = params.indexOf('&', i);
	    return params.substring(i, (j == -1)? params.length() : j);
	}
    }

   /**
    * Read applet parameters, make the GUI.
    */
    public void init() {
	Color bg = null;

	String s;

	if((s = getParameter("bgcolor")) != null && s.charAt(0) == '#') {
	    bg = new Color(Integer.parseInt(s.substring(1), 16));
	    setBackground(bg);
	}

	GridBagLayout gbl = new GridBagLayout();
	GridBagConstraints gbc = new GridBagConstraints();
	Container contentPane = getContentPane();
	contentPane.setLayout(gbl);

	////////////////////////////////////////////////////
	// Calibration and options panel
	////////////////////////////////////////////////////
	JPanel calpan = new JPanel();
	GridBagLayout cbl = new GridBagLayout();
	GridBagConstraints cbc = new GridBagConstraints();
	cbc.weightx = cbc.weighty = 1.0;
	calpan.setLayout(cbl);
	for(int i=0; i<3; ++i) {
	    cbc.gridx = 2+2*i;
	    cbc.gridy = 0;
	    cbc.anchor = GridBagConstraints.WEST;
	    String[] d = new String[2];
	    String label;
	    switch(i) {
	    case 0:
		d[0] = "Check it to make X axis logscaled";
		d[1] = "Uncheck it to make X axis linear";
		label = "logscale X";
		break;
	    case 1:
		d[0] = "Check it to make Y axis logscaled";
		d[1] = "Uncheck it to make Y axis linear";
		label = "logscale Y";
		break;
	    default:
		d[0] = "Automatic ordering of data points";
		d[1] = "Uncheck it to disable automatic ordering of data points";
		label = "autosort";
		cbc.insets.left = getFontMetrics(btnfnt).getHeight()*2;
	    }
	    NiceButton cb = new NiceButton("", d);
	    if(i == 2) {
		sortcb = cb;
	    } else {
		logscb[i] = cb;
	    }
	    cbl.setConstraints(cb, cbc);
	    calpan.add(cb);
	    cb.setStyle(NiceButton.HIDDEN3D);
	    cb.setFont(btnfnt);
	    cb.addMouseListener(this);
	    cbc.insets.left = 0;
	    cbc.gridx++;
	    JLabel l = new JLabel(label);
	    cbl.setConstraints(l, cbc);
	    calpan.add(l);
	}
	for(int i=0; i<3; ++i) {
	    cbc.gridx = 0;
	    cbc.gridy = 1+i;
	    cbc.gridwidth = 1;
	    cbc.fill = GridBagConstraints.HORIZONTAL;
	    String[] d = new String[2];
	    d[1] = "Click to get out of calibration mode";
	    String blab;
	    if(i == 0) {
		d[0] = "Set origin";
		blab = " Origin ";
	    } else if(i == 1) {
		d[0] = "Set calibration point on X axis";
		blab = " X calibration point ";
	    } else {
		d[0] = "Set calibration point on Y axis";
		blab = " Y calibration point ";
	    }
	    cbl.setConstraints(calbtn[i] = new NiceButton(blab, d), cbc);
	    calpan.add(calbtn[i]);
	    calbtn[i].setFont(btnfnt);
	    calbtn[i].addMouseListener(this);
	    cbc.gridwidth = 1;
	    for(int j=0; j<2; ++j) {
		JLabel l = new JLabel((j==0)? "X=":"Y=");
		cbc.gridx = 2+2*j;
		cbc.fill = GridBagConstraints.NONE;
		cbl.setConstraints(l, cbc);
		calpan.add(l);
		cbc.gridx++;
		cbc.fill = GridBagConstraints.HORIZONTAL;
		int k = 2*i+j;
		caltxt[k] = new JTextField(10);
		if((i == 1 && j == 1) || (i == 2 && j == 0)) {
		    caltxt[k].setEditable(false);
		}
		cbl.setConstraints(caltxt[k], cbc);
		calpan.add(caltxt[k]);
	    }
	}
	gbc.gridx = 0;
	gbc.gridy = 0;
	gbc.gridwidth = 5;
	gbl.setConstraints(calpan, gbc);
	contentPane.add(calpan);

	////////////////////////////////////////////////////
	// Current coordinates
	////////////////////////////////////////////////////
	crdtxt = new NiceButton("                                                                ", "");
	crdtxt.setStyle(NiceButton.LABEL);
	crdtxt.setFont(fixfnt);
	gbc.gridy = 1;
	gbc.gridwidth = 5;
	gbl.setConstraints(crdtxt, gbc);
	contentPane.add(crdtxt);

	////////////////////////////////////////////////////
	// Left button panel
	////////////////////////////////////////////////////
	JPanel lbtpan = new JPanel();
	JButton markbtn = new JButton(markAction);
	markbtn.setFont(btnfnt);
	markbtn.setIcon(new ImageIcon(mkImg("1000000000000000000000000W300V00+30uF0W-00y10W3000000000000000000000", 0xff000000)));
	markbtn.setRolloverIcon(new ImageIcon(mkImg("1000000000000000100400G00W300V00+30--1W-00y10W300400G000100000000000", 0xff000000)));
	lbtpan.add(markbtn);
	markbtn = new JButton(markErrorAction);
	markbtn.setFont(btnfnt);
	markbtn.setIcon(new ImageIcon(mkImg("1000000000000000000000000W300V00+30uF0W-00y10W3000000000000000000000", 0xff000000)));
	markbtn.setRolloverIcon(new ImageIcon(mkImg("1000000000000000100400G00W300V00+30--1W-00y10W300400G000100000000000", 0xff000000)));
	lbtpan.add(markbtn);

	////////////////////////////////////////////////////
	// Data points panel
	////////////////////////////////////////////////////
	GridBagLayout ptl = new GridBagLayout();
	GridBagConstraints ptc = new GridBagConstraints();
	(ptpan = new JPanel()).setLayout(ptl);

	ptc.gridx = 0;
	ptc.gridy = 0;
	ptc.anchor = GridBagConstraints.NORTHWEST;
	ptc.weightx = ptc.weighty = 0;
	ptc.fill = GridBagConstraints.NONE;
	ptc.gridx = 1;

	////////////////////////////////////////////////////
	// Right button panel
	////////////////////////////////////////////////////
	JPanel rbtpan = new JPanel();
	String[] desc = new String[2];
	String eraseicon = "1000000000000000000m70WW00n402Wtv0U7SuTEW080201408800V00000000000000";
	Image[] icons = new Image[5];
	icons[0] = mkImg(eraseicon, 0xff000000);
	icons[NiceButton.MOUSEOVER] = mkImg("1000000000000000000+00440Oc0024tHGS72nT4408G0OW00110u300000000000000", 0xff000000);
	icons[NiceButton.DOWN] = icons[NiceButton.DOWN|NiceButton.MOUSEOVER] = mkImg("100000000000000000u30GG0WP208G0711S84mHG0W01W120440WF000000000000000", 0xff000000);
	icons[NiceButton.DISABLED] = mkImg(eraseicon, 0x7f000000);
	desc[0] = "delete a data point";
	desc[1] = "click to get out of delete mode";
	erasebtn = new NiceButton(" Erase ", desc);
	erasebtn.setEnabled(false);
	erasebtn.setFont(btnfnt);
	erasebtn.setIcons(icons);
	erasebtn.setStyle(NiceButton.HIDDEN3D);
	erasebtn.addMouseListener(this);
	rbtpan.add(erasebtn);
	icons = new Image[5];
	icons[0] = mkImg("1+--800Y008oZd800Y00820W8FUY00820W800Yyu920W800Y008oZd800Y00820Wu--3", 0xff000000);
	showbtn = new NiceButton(" Show ", "show table of data points");
	showbtn.setEnabled(false);
	showbtn.setFont(btnfnt);
	showbtn.setIcons(icons);
	showbtn.setStyle(NiceButton.HIDDEN3D);
	showbtn.addMouseListener(this);
	rbtpan.add(showbtn);

	////////////////////////////////////////////////////
	// Left+data points+right button panel
	////////////////////////////////////////////////////
	gbc.gridy = 2;
	gbc.gridwidth = 5;
	gbc.fill = GridBagConstraints.HORIZONTAL;
	JPanel uppan = new JPanel();
	GridBagLayout upl = new GridBagLayout();
	GridBagConstraints upc = new GridBagConstraints();
	uppan.setLayout(upl);
	upc.anchor = GridBagConstraints.NORTHWEST;
	upc.gridx = 0;
	upc.gridy = 0;
	upc.fill = GridBagConstraints.NONE;
	upc.weightx = upc.weighty = 0.0;
	upl.setConstraints(lbtpan, upc);
	uppan.add(lbtpan);
	upc.gridx = 1;
	upc.fill = GridBagConstraints.BOTH;
	upc.weightx = upc.weighty = 1.0;
	upl.setConstraints(ptpan, upc);
	uppan.add(ptpan);
	upc.gridx = 2;
	upc.fill = GridBagConstraints.NONE;
	upc.weightx = upc.weighty = 0.0;
	upl.setConstraints(rbtpan, upc);
	uppan.add(rbtpan);
	gbl.setConstraints(uppan, gbc);
	contentPane.add(uppan);

	////////////////////////////////////////////////////
	// Image canvases and scrollbars
	////////////////////////////////////////////////////
	gbc.gridx = 0;
	gbc.gridy = 4;
	gbc.gridwidth = 3;
	gbc.fill = GridBagConstraints.BOTH;
	gbc.weightx = 0.25/3;
	gbc.weighty = 1.0;
	imgcany = new ImgCanvas(ImgCanvas.VERTICAL);
	imgcany.setBackground(bg);
	imgcany.addMouseListener(this);
	imgcany.addKeyListener(this);
	gbl.setConstraints(imgcany, gbc);
	contentPane.add(imgcany);

	gbc.gridx = 3;
	gbc.gridwidth = 1;
	gbc.weightx = gbc.weighty = 0.0;
	gbc.fill = GridBagConstraints.VERTICAL;
	gbl.setConstraints(yscrbar = new JScrollBar(JScrollBar.VERTICAL), gbc);
	contentPane.add(yscrbar);
	yscrbar.addAdjustmentListener(this);

	gbc.gridx = 4;
	gbc.gridy = 5;
	gbc.weightx = gbc.weighty = 0.0;
	gbc.fill = GridBagConstraints.HORIZONTAL;
	gbl.setConstraints(xscrbar = new JScrollBar(JScrollBar.HORIZONTAL), gbc);
	contentPane.add(xscrbar);
	xscrbar.addAdjustmentListener(this);

	gbc.gridy = 4;
	gbc.weightx = 1.0;
	gbc.weighty = 1.0;
	gbc.fill = GridBagConstraints.BOTH;
	imgcanc = new ImgCanvas(ImgCanvas.CENTRAL);
	imgcanc.setBackground(bg);
	imgcanc.addMouseListener(this);
	imgcanc.addKeyListener(this);
	gbl.setConstraints(imgcanc, gbc);
	contentPane.add(imgcanc);

	gbc.gridy = 6;
	gbc.weightx = 1.0;
	gbc.weighty = 0.25/4;
	imgcanx = new ImgCanvas(ImgCanvas.HORIZONTAL);
	imgcanx.setBackground(bg);
	imgcanx.addMouseListener(this);
	imgcanx.addKeyListener(this);
	gbl.setConstraints(imgcanx, gbc);
	contentPane.add(imgcanx);

	////////////////////////////////////////////////////
	// Buttons in the bottom left corner
	////////////////////////////////////////////////////
	gbc.fill = GridBagConstraints.NONE;
	gbc.gridheight = 1;
	gbc.gridx = 0;
	gbc.gridy = 6;
	gbc.gridwidth = 1;
	gbc.weightx = gbc.weighty = 0.0;
	desc = new String[2];
	desc[0] = desc[1] = "1/2 magnification";
	icons = new Image[5];
	icons[0] = mkImg("1000000000000000000000000u-1W160AK08V1W450IK08H1W+506O0u-10000000000", 0xff000000);
	magbtn[0] = new NiceButton(" 1/2 ", desc);
	magbtn[0].setIcons(icons);
	magbtn[0].addMouseListener(this);

	desc = new String[2];
	desc[0] = desc[1] = "No magnification";
	icons[0] = mkImg("1000000000000000000000000u-1W0402G0801W0402G0801W0402G0u-10000000000", 0xff000000);
	magbtn[1] = new NiceButton("  1  ", desc);
	magbtn[1].setIcons(icons);
	magbtn[1].addMouseListener(this);

	desc = new String[2];
	desc[0] = desc[1] = "Double magnification";
	icons[0] = mkImg("1---F00O10m900710Q80e11G6u-PW0a12G680PW0a12G680PW0a12G6y-PC0eD00---F", 0xff000000);
	magbtn[2] = new NiceButton("  2  ", desc);
	magbtn[2].setIcons(icons);
	magbtn[2].addMouseListener(this);

	gbc.anchor = GridBagConstraints.NORTHWEST;
	for(int i=0; i<3; ++i) {
	    gbc.gridx = i;
	    gbl.setConstraints(magbtn[i], gbc);
	    magbtn[i].setStyle(NiceButton.HIDDEN3D);
	    magbtn[i].setFont(btnfnt);
	    contentPane.add(magbtn[i]);
	}
	magbtn[1].setState(true);

	////////////////////////////////////////////////////
	// Set the states of the fields and load image
	////////////////////////////////////////////////////
	reset(); // set the states of the fields
	if((s = getParameter("img")) != null) {
	    loadImage(s, false);
	}
    }

    /**
     * Start the painting thread.
     */
    public void start() {
	if(thread == null) {
	    (thread = new Thread(this, "Grdig")).start();
	}
    }

    /**
     * Remove all references to the painting thread.
     */
    public void stop() {
	thread = null;
    }

    /**
     * Run the painting thread.
     */
    public synchronized void run() {
	while(thread != null) {
	    long t = System.currentTimeMillis();
	    long dt = t - time;
	    int iw = 0;
	    int ih = 0;
	    if(image != null) {
		iw = image.getWidth(null);
		ih = image.getHeight(null);
	    }
	    if(iw>0 && ih>0) {
		Point mouloc = imgcanc.getMouseLoc();
		Dimension ics = imgcanc.getSize();
		double xc = 0.5*ics.width;
		double yc = 0.5*ics.height;
		if(mdown && t-mdownwhen>200) {
		    imgcanc.setSmartmode(true);
		    double dx = mouloc.x - xc;
		    double dy = mouloc.y - yc;
		    int maxr = imgcanc.getRadius();
		    double c = dt*magn/(5*maxr);
		    setc(xcenter + dx*c, ycenter + dy*c);
		}
		int sw = ics.width;
		int sh = ics.height;
		int px = (int)(magn*sw + 0.5);
		int py = (int)(magn*sh + 0.5);
		int xmax = (int)(magn*iw+0.5);
		int ymax = (int)(magn*ih+0.5);
		if(!scrollbug) {
		    xmax += px;
		    ymax += py;
		}
		xscrbar.setValues((int)(xcenter*magn+0.5), px, 0, xmax);
		yscrbar.setValues((int)(ycenter*magn+0.5), py, 0, ymax);
		xscrbar.setBlockIncrement(px);
		yscrbar.setBlockIncrement(py);
	    }
	    try {
		wait(100);
	    } catch(InterruptedException e) {
	    }
	    time = t;
	}
    }

   /**
    * Mouse entered a button.
    */
    public final void mouseEntered(MouseEvent e) {
	Object target = e.getSource();
	if(target instanceof NiceButton && params == null) {
	    showStatus(((NiceButton)target).getDescription());
	}
    }

   /**
    * A button is pressed.
    */
    public void mousePressed(MouseEvent e) {
	Object target = e.getSource();
	if(target == imgcanc) {
	    mdown = true;
	    mdownwhen = System.currentTimeMillis();
	}
	if(target instanceof ImgCanvas) {
	    ((Component)target).requestFocus();
	}
    }

   /**
    * A button is released.
    */
    public void mouseReleased(MouseEvent e) {
	Object target = e.getSource();
	if(target instanceof NiceButton && params == null)
	    showStatus(((NiceButton)target).getDescription());
	if(target == imgcanc) {
	    mdown = false;
	    imgcanc.setSmartmode(false);
	    if(currentIndex != -1) {
		setp();
	    }
	    if(System.currentTimeMillis() - mdownwhen <= 200) {
		Dimension sz = imgcanc.getSize();
		Point mouloc = imgcanc.getMouseLoc();
		int x0 = (int) Math.round(sz.width/2 - xcenter*magn);
		int y0 = (int) Math.round(sz.height/2 - ycenter*magn);
		setc((mouloc.x-x0)/magn, (mouloc.y-y0)/magn);
	    }
	} else if(target == logscb[0] || target == logscb[1]) {
	    setc(xcenter, ycenter); // just to redraw it
	} else if(target == erasebtn) {
	    for(int i=ptpan.getComponentCount()-1; i>=0; --i) {
		NiceButton b = (NiceButton) ptpan.getComponent(i);
		if(b.getState()) {
		    rmp(i);
		    erasebtn.setState(false);
		}
	    }
	    refreshPoints();
	} else if(target == showbtn) {
	    String s = getData(null);
	    int i = s.indexOf('\n');
	    int n = (points.size()-6)/3;
	    new ViewFrame(s.substring(i+1), (n>35)? 40 : n+5, 32);
	} else if(target instanceof NiceButton) {
	    for(int i=0; i<3; ++i) {
		if(target == magbtn[i]) {
		    for(int j=0; j<3; ++j) {
			if(target != magbtn[j])
			    magbtn[j].setState(false);
		    }
		    if(!magbtn[i].getState()) {
			magbtn[i = 1].setState(true);
		    }
		    magn = 0.5*(1<<i);
		    imgcanc.setPos(xcenter, ycenter, magn);
		    imgcanx.setPos(xcenter,
				   ((Double)points.elementAt(3)).doubleValue(),
				   magn);
		    imgcany.setPos(((Double)points.elementAt(4)).doubleValue(),
				   ycenter, magn);
		    return;
		}
	    }
	    for(int i = 0; i < 3; ++i)
		if(target == calbtn[i]) {
		    if(calbtn[i].getState()) {
			currentIndex = -1;
			setc(((Double)points.elementAt(2*i)).doubleValue(),
			     ((Double)points.elementAt(2*i+1)).doubleValue());
			currentIndex = i;
			for(int j=0; j<3; ++j) {
			    if(j != i) {
				calbtn[j].setState(false);
			    }
			}
			for(int j=0; j<ptpan.getComponentCount(); ++j) {
			    ((NiceButton)ptpan.getComponent(j)).setState(false);
			}
			return;
		    } else {
			currentIndex = -1;
			return;
		    }
		}
	    NiceButton b = null;
	    for(int i = ptpan.getComponentCount() - 1; i >= 0; --i) {
		b = (NiceButton) ptpan.getComponent(i);
		if(target == b) {
		    currentIndex = -1;
		    if(b.getState()) {
			setc(((Double)points.elementAt(3*i + 6)).doubleValue(),
			     ((Double)points.elementAt(3*i + 7)).doubleValue());
			currentIndex = i+3;
		    }
		    break;
		}
	    }
	    if(b != null && b.getState()) {
		int n = ptpan.getComponentCount();
		for(int i=n-1; i>=0; --i) {
		    NiceButton bb = (NiceButton) ptpan.getComponent(i);
		    if(bb.getState()) {
			if(erasebtn.getState()) {
			    rmp(i);
			} else if(b != bb) {
			    bb.setState(false);
			}
		    }
		}
		calbtn[0].setState(false);
		calbtn[1].setState(false);
		calbtn[2].setState(false);
		if(n != ptpan.getComponentCount()) {
		    refreshPoints();
		}
	    }
	}
    }

    public final void mouseClicked(MouseEvent e) { }
    public final void mouseExited(MouseEvent e) { }

   /**
    * A key was pressed.
    */
    public void keyPressed(KeyEvent e) {
	int key = e.getKeyCode();
	Object target = e.getSource();
	double d = 1/magn;
	if(target instanceof ImgCanvas) {
	    switch(key) {
	    case KeyEvent.VK_LEFT: setc(xcenter-d, ycenter); break;
	    case KeyEvent.VK_RIGHT: setc(xcenter+d, ycenter); break;
	    case KeyEvent.VK_UP: setc(xcenter, ycenter-d); break;
	    case KeyEvent.VK_DOWN: setc(xcenter, ycenter+d); break;
	    }
	}
    }

    public void keyReleased(KeyEvent e) { }
    public void keyTyped(KeyEvent e) { }

   /**
    * Scrollbar events.
    */
    public void adjustmentValueChanged(AdjustmentEvent e) {
	Object target = e.getSource();
	double arg = e.getValue()/magn;
	if(target == xscrbar) {
	    setc(arg/magn, ycenter);
	} else if(target == yscrbar) {
	    setc(xcenter, arg/magn);
	}
    }

   /**
    * Create icon from base64 encoded 20x20x2 bit image.
    */
    private Image mkImg(String s, int black) {
	int[] bm = new int[20*20];
	int[] colors = new int[4];
	int bpp = s.charAt(0)-'0'; // bits per pixel
	int ppc = 6/bpp; // pixels per character
	int mask = (1<<bpp)-1;
	colors[0] = 0x00ffffff;
	colors[1] = black;
	for(int i=0; i<400; ++i) {
	    int c = s.charAt(i/ppc+1);
	    int z = (c=='+')? 62 : (c=='-')? 63 : (c>='a')? c-'a'+36 :
		    (c>='A')? c-'A'+10 : c-'0';
	    int ci = (z>>(bpp*(i%ppc)))&mask;
	    bm[i] = colors[ci];
	}
	MemoryImageSource mis = new MemoryImageSource(20, 20, bm, 0, 20);
	return createImage(mis);
    }

    /**
     * Renumber the data points, recalculate button panel layout.
     */
    private void refreshPoints() {
	GridBagLayout ptl = (GridBagLayout) ptpan.getLayout();
	GridBagConstraints ptc = new GridBagConstraints();
	for(int j=0; j<ptpan.getComponentCount(); ++j) {
	    NiceButton b = (NiceButton) ptpan.getComponent(j);
	    b.setStyle(NiceButton.HIDDEN3D);
	    b.setLabel(" ".concat(String.valueOf(j+1)).concat(" "));
	    ptc.gridx = j;
	    ptc.gridy = 0;
	    ptc.weightx = ptc.weighty = 1.0;
	    ptc.fill = GridBagConstraints.BOTH;
	    ptl.setConstraints(b, ptc);
	}
	ptpan.validate();
    }

    /**
     * Remove a data point.
     */
    private void rmp(int i) {
	NiceButton b = (NiceButton) ptpan.getComponent(i);
	ptpan.remove(b);
	points.removeElementAt(3*i + 6);
	points.removeElementAt(3*i + 6);
	points.removeElementAt(3*i + 6);
	if(ptpan.getComponentCount() == 0) {
	    erasebtn.setState(false);
	    erasebtn.setEnabled(false);
	    showbtn.setEnabled(false);
	}
	imgcanc.repaint();
	imgcanx.repaint();
	imgcany.repaint();
	if(currentIndex != -1) {
	    if(currentIndex > i+3) {
		--currentIndex;
	    } else if(currentIndex == i+3) {
		currentIndex = -1;
	    }
	}
    }

    /**
     * Mark data point or change location of current one.
     */
    private void setp() {
	int i = points.size();
	if(sortcb.getState()) {
	    double v = xcenter;
	    i = 6;
	    while(i < points.size()) {
		double u = ((Double)points.elementAt(i-3)).doubleValue();
		double w = ((Double)points.elementAt(i)).doubleValue();
		if((i == 6 || u < v) && v < w) {
		    break;
		}
		i += 3;
	    }
	}
	setp(xcenter, ycenter, 0, i);
    }

    /**
     * Mark data point or change location of current one.
     */
    public void setp(double x, double y, double dy, int i) {
	Double X = new Double(x);
	Double Y = new Double(y);
	Double dY = new Double(dy);
	if(currentIndex != -1) {
	    if(currentIndex < 3) {
		points.setElementAt(X, 2*currentIndex);
		points.setElementAt(Y, 2*currentIndex + 1);
	    } else {
		points.setElementAt(X, 6 + 3*(currentIndex - 3));
		points.setElementAt(Y, 6 + 3*(currentIndex - 3) + 1);
		points.setElementAt(dY, 6 + 3*(currentIndex - 3) + 2);
	    }
	} else {
	    if(i == -1) {
		i = points.size();
	    }
	    points.insertElementAt(X, i);
	    points.insertElementAt(Y, i + 1);
	    points.insertElementAt(dY, i + 2);
	    String[] desc = new String[2];
	    desc[0] = "select data point for moving or deleting";
	    desc[1] = "unselect data point";
	    NiceButton b = new NiceButton(" ", desc);
	    b.setFont(btnfnt);
	    b.addMouseListener(this);
	    ptpan.add(b, (i - 6)/3);
	    refreshPoints();
	    imgcanc.repaint();
	    imgcanx.repaint();
	    imgcany.repaint();
	    erasebtn.setEnabled(true);
	    showbtn.setEnabled(true);
	}
	erasebtn.setState(false);
    }

    /**
     * Reset the state.
     */
    public void reset() {
	String s;
	currentIndex = -1;
	points = new Vector();
	imgcanc.setPoints(points);
	imgcanx.setPoints(points);
	imgcany.setPoints(points);
	ptpan.removeAll();
	imgname = getParameter("img");
	double calx[] = {0.0, 0.0, 1.0, 0.0, 0.0, 1.0}; // calibration points
	try {
	    double calp[] = {0.0, 0.0, 100.0, 0.0, 0.0, 100.0};
	    for(int i = 0; i < 6; ++i) {
		char[] c = new char[2];
		c[0] = (char)('p'+(i&1));
		c[1] = (char)('0'+(i>>1));
		double x = calp[i];
		if((s = getParameter(new String(c))) != null) {
		    x = Double.valueOf(s).doubleValue();
		}
		points.addElement(new Double(x));
	    }
	    if((s = getParameter("x0")) != null) {
		calx[0] = Double.valueOf(s).doubleValue();
	    }
	    if((s = getParameter("y0")) != null) {
		calx[1] = Double.valueOf(s).doubleValue();
	    }
	    if((s = getParameter("x1")) != null) {
		calx[2] = Double.valueOf(s).doubleValue();
	    }
	    if((s = getParameter("y2")) != null) {
		calx[5] = Double.valueOf(s).doubleValue();
	    }
	} catch(NumberFormatException exc) {
	    exc.printStackTrace();
	}
	calx[3] = calx[1];
	calx[4] = calx[0];
	for(int k=0; k<6; ++k) {
	    caltxt[k].setText(String.valueOf(calx[k]));
	}
	for(int k=0; k<2; ++k) {
	    String p = (k==0)? "logx" : "logy";
	    logscb[k].setState((s = getParameter(p)) != null && s.equals("1"));
	}
	sortcb.setState((s = getParameter("sort")) != null && s.equals("1"));
    }

    /**
     * Get calibration point coordinate from its text field.
     */
    private double getCalPoint(int i) {
	String s = caltxt[i].getText();
	try {
	    return Double.valueOf(s).doubleValue();
	} catch(NumberFormatException e) {
	    double x;
	    if(logscb[i&1].getState()) {
		s = "1";
		x = 1.0;
	    } else {
		s = "0";
		x = 0.0;
	    }
	    caltxt[i].setText(s);
	    return x;
	}
    }

    /**
     * Change the central coordinates.
     */
    private synchronized void setc(double x, double y) {
	int w = 1;
	int h = 1;
	if(image != null) {
	    w = image.getWidth(null);
	    h = image.getHeight(null);
	}
	xcenter = x;
	ycenter = y;
	if(xcenter < 0) {
	    xcenter = 0;
	}
	if(xcenter >= w) {
	    xcenter = w-1;
	}
	if(ycenter < 0) {
	    ycenter = 0;
	}
	if(ycenter >= h) {
	    ycenter = h-1;
	}
	if(currentIndex != -1 && !erasebtn.getState()) {
	    points.setElementAt(new Double(xcenter), 2*currentIndex);
	    points.setElementAt(new Double(ycenter), 2*currentIndex+1);
	}
	imgcanc.setPos(xcenter, ycenter, magn);
	imgcanx.setPos(xcenter, ((Double)points.elementAt(3)).doubleValue(),
		       magn);
	imgcany.setPos(((Double)points.elementAt(4)).doubleValue(), ycenter,
		       magn);
	String s = "p=".concat(pri(xcenter, 8, -1));
	s = s.concat(" q=").concat(pri(ycenter, 8, -1));
	double[] X = transform(xcenter, ycenter, 0.0, false);
	s = s.concat(" x=").concat(pri(X[0], 12, 0));
	s = s.concat(" y=").concat(pri(X[1], 12, 1));
	crdtxt.setLabel(s);
	s = caltxt[1].getText();
	if(!(caltxt[3].getText()).equals(s)) {
	    caltxt[3].setText(s);
	}
	s = caltxt[0].getText();
	if(!(caltxt[4].getText()).equals(s)) {
	    caltxt[4].setText(s);
	}
    }

    /**
     * Transforms screen coordinates to the plot's coordinate system.
     */
    public synchronized double[] transform(double x, double y,
					   double dy, boolean inv) {
	double u0 = ((Double)points.elementAt(0)).doubleValue();
	double v0 = ((Double)points.elementAt(1)).doubleValue();
	double u1 = ((Double)points.elementAt(2)).doubleValue();
	double v1 = ((Double)points.elementAt(3)).doubleValue();
	double du1 = u1-u0;
	double dv1 = v1-v0;
	double r1 = Math.sqrt(du1*du1 + dv1*dv1);
	double u2 = ((Double)points.elementAt(4)).doubleValue();
	double v2 = ((Double)points.elementAt(5)).doubleValue();
	double du2 = u2-u0;
	double dv2 = v2-v0;
	double r2 = Math.sqrt(du2*du2 + dv2*dv2);
	double x0 = getCalPoint(0);
	double y0 = getCalPoint(1);
	double x1 = getCalPoint(2);
	double y2 = getCalPoint(5);
	boolean logScaleX = logscb[0].getState();
	boolean logScaleY = logscb[1].getState();
	if(logScaleX) {
	    x0 = Math.log(x0);
	    x1 = Math.log(x1);
	}
	if(logScaleY) {
	    y0 = Math.log(y0);
	    y2 = Math.log(y2);
	}
	if(inv) {
	    double[] X = new double[3];
	    double y_err = y + dy;
	    if(logScaleX) {
		x = Math.log(x);
	    }
	    if(logScaleY) {
		y = Math.log(y);
		y_err = Math.log(y_err);
	    }
	    X[0] = u0 + du1*(x-x0)/(x1-x0) + du2*(y-y0)/(y2-y0);
	    X[1] = v0 + dv1*(x-x0)/(x1-x0) + dv2*(y-y0)/(y2-y0);
	    X[2] = v0 + dv1*(x-x0)/(x1-x0) + dv2*(y_err-y0)/(y2-y0) - X[1];

	    // quantize the coordinate with the assumption that the
	    // is an integer power of 2 and no more than 16.
	    X[0] = Math.round(X[0]*16)/16;
	    X[1] = Math.round(X[1]*16)/16;
	    X[2] = Math.round(X[2]*16)/16;
	    return X;
	} else {
	    double[] X0 = transform(x, y, logScaleX, logScaleY,
				    x0, y0, x1, y2,
				    u0, v0, du1, dv1, du2, dv2, r1, r2);
	    double[] Xe = transform(x, y + dy, logScaleX, logScaleY,
				    x0, y0, x1, y2,
				    u0, v0, du1, dv1, du2, dv2, r1, r2);
	    double[] X = new double[3];
	    X[0] = X0[0];
	    X[1] = X0[1];
	    X[2] = Xe[1] - X0[1];
	    return X;
	}
    }

    private static double[] transform(double x, double y,
				      boolean logScaleX, boolean logScaleY,
				      double x0, double y0,
				      double x1, double y2,
				      double u0, double v0,
				      double du1, double dv1,
				      double du2, double dv2,
				      double r1, double r2) {

	double dux = ((u0*dv1-v0*du1)*du2 - (x*dv2-y*du2)*du1) /
	    (du2*dv1 - du1*dv2) - u0;
	double dvx = ((u0*dv1-v0*du1)*dv2 - (x*dv2-y*du2)*dv1) /
	    (du2*dv1 - du1*dv2) - v0;
	double qx = 0.0;
	if(r1 > 1e-6) {
	    qx = (dux*du1 + dvx*dv1) / (r1*r1);
	}
	double duy = ((u0*dv2-v0*du2)*du1 - (x*dv1-y*du1)*du2) /
	    (du1*dv2 - du2*dv1) - u0;
	double dvy = ((u0*dv2-v0*du2)*dv1 - (x*dv1-y*du1)*dv2) /
	    (du1*dv2 - du2*dv1) - v0;
	double qy = 0.0;
	if(r2 > 1e-6) {
	    qy = (duy*du2 + dvy*dv2) / (r2*r2);
	}
	double[] X = new double[2];
	X[0] = x0 + (x1-x0)*qx;
	X[1] = y0 + (y2-y0)*qy;
	if(logScaleX) {
	    X[0] = Math.exp(X[0]);
	}
	if(logScaleY) {
	    X[1] = Math.exp(X[1]);
	}
	return X;
    }

    /**
     * Format a floating point number.
     */
    private String pri(double x, int w, int i) {
	String s;
	if(i == -1) {
	    s = String.valueOf(x);
	} else {
	    s = sci(x, w-8);
	}
	return s.concat("                                ").substring(0, w);
    }

    /**
     * Scientific (exponential) number formatting.
     */
    public static String sci(double x, int prec) {
	final double log10 = Math.log(10.0);
	if(x < 0) {
	    return "-".concat(sci(-x, prec));
	}
	if(x <= Double.MIN_VALUE) {
	    return (prec==0)? "0E0"
		: "0.00000000000000000000".substring(0, prec+2).concat("E0");
	}
	StringBuffer sbuf = new StringBuffer();
	double y = x;
	double smallest = 0;
	int ly = (int) Math.floor(Math.log(y)/log10);
	for(int i=0; i<=prec+1; ++i) {
	    int l = ly-i;
	    double a = Math.exp(log10*l);
	    int b = (int) (y/a);
	    y -= a*b;
	    if(i == 0) {
		smallest = Math.exp(log10*(l-prec));
	    }
	    if(i <= prec) {
		sbuf.append(b);
		if(i==0 && i<=prec) {
		    sbuf.append('.');
		}
	    } else if(b >= 5) {
		return sci(x+smallest/2, prec);
	    }
	}
	sbuf.append("E");
	sbuf.append((ly<0)? '-' : '+');
	if(ly < 0) {
	    ly = -ly;
	}
	if(ly < 10) {
	    sbuf.append('0');
	}
	sbuf.append(ly);
	return sbuf.toString();
    }

   /**
    * Download image from the net.
    */
    public void loadImage(String s, boolean wait) {
	imgname = s;
	widthknown = heightknown = centralized = false;
	try {
	    Image img;
	    if(params == null) { // in an applet
		URL u = new URL(getDocumentBase(), s);
		s = u.toString();
		img = getImage(u);
	    } else { // application
		img = Toolkit.getDefaultToolkit().getImage(s);
	    }
	    if(img != null) {
		if(wait) {
		    MediaTracker t = new MediaTracker(this);
		    t.addImage(img, 0);
		    t.waitForAll();
		}
		image = img;
		centralize();
		imgcanc.setImage(img);
		imgcanx.setImage(img);
		imgcany.setImage(img);
		imgcanc.repaint();
		imgcanx.repaint();
		imgcany.repaint();
	    } else {
		removeAll();
		setLayout(new GridLayout(1,1));
		getContentPane().add(new JLabel(
		    "ERROR: cannot get image \"".concat(s).concat("\"")));
		validate();
	    }
	} catch(Throwable e) {
	    e.printStackTrace();
	}
    }

    /**
     * Resize the window and move the cross to the center.
     */
    private void centralize() {
	int width = image.getWidth(this);
	int height = image.getHeight(this);
	if(width > 0 && height > 0) {
	    setc(0.5*width, 0.5*height);
	    Container p = getParent();
	    if(p != null && p instanceof Frame) {
		((Frame)p).pack();
	    }
	    centralized = true;
	}
    }

    /**
     * Call centralize() when the image size becomes available.
     */
    public boolean imageUpdate(Image img, int flags,
                               int x, int y, int w, int h)
    {
        if((flags & WIDTH) != 0) {
	    widthknown = true;
	}
        if((flags & HEIGHT) != 0) {
	    heightknown = true;
	}
        if((flags & (FRAMEBITS|ALLBITS)) != 0) {
	    widthknown = heightknown = true;
	}
	if(widthknown && heightknown && !centralized) {
	    centralize();
	}
	return super.imageUpdate(img, flags, x, y, w, h);
    }

    /**
     * Get the data file.
     */
    public String getData(String filename) {
	StringBuffer s = new StringBuffer("# img=");
	if(filename != null || imgname != null) {
	    s.append((filename != null)? filename : imgname);
	}
	s.append("&logx=");
	s.append(logscb[0].getState()? '1' : '0');
	s.append("&logy=");
	s.append(logscb[1].getState()? '1' : '0');
	s.append("&sort=");
	s.append(sortcb.getState()? '1' : '0');
	for(int i = 0; i < 6; ++i) {
	    getCalPoint(0);
	}
	s.append("&x0=");
	s.append(caltxt[0].getText());
	s.append("&y0=");
	s.append(caltxt[1].getText());
	s.append("&x1=");
	s.append(caltxt[2].getText());
	s.append("&y2=");
	s.append(caltxt[5].getText());
	for(int i=0; i<3; ++i) {
	    for(int j=0; j<2; ++j) {
		s.append('&');
		s.append((char)('p'+j));
		s.append((char)('0'+i));
		s.append('=');
		s.append((Double)points.elementAt(2*i+j));
	    }
	}
	s.append('\n');
	for(int i = 6; i < points.size(); i += 3) {
	    double xx = ((Double)points.elementAt(i)).doubleValue();
	    double yy = ((Double)points.elementAt(i+1)).doubleValue();
	    double dyy = ((Double)points.elementAt(i+2)).doubleValue();
	    double[] X = transform(xx, yy, dyy, false);
	    s.append(pri(X[0], 12, 0));
	    s.append(' ');
	    s.append(pri(X[1], 12, 1).trim());
	    s.append(' ');
	    s.append(pri(Math.abs(X[2]), 12, 1).trim());
	    s.append('\n');
	}
	return s.toString();
    }
}
